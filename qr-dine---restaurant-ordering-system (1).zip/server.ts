import express from "express";
import { createServer as createViteServer } from "vite";
import expressWs from "express-ws";
import { v4 as uuidv4 } from "uuid";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const { app } = expressWs(express());
const PORT = 3000;

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

app.use(express.json());

// --- Mock Data & Store ---
interface MenuItem {
  id: string;
  name: { en: string; ar: string };
  description: { en: string; ar: string };
  price: number;
  category: { en: string; ar: string };
  image: string;
  available: boolean;
  tags?: ("spicy" | "vegan" | "bestseller" | "new" | "chef-choice")[];
  recommendations?: string[];
  prepTime?: number;
  calories?: number;
}

interface OrderItem {
  id: string;
  menuItemId: string;
  name: string;
  quantity: number;
  price: number;
  instructions?: string;
  addOns?: { name: string; price: number }[];
}

interface Order {
  id: string;
  tableId: string;
  tableNumber: string;
  items: OrderItem[];
  status: "pending" | "preparing" | "ready" | "paid";
  total: number;
  createdAt: string;
  customerPhone?: string;
  estimatedReadyTime?: string;
}

interface Table {
  id: string;
  number: string;
  status: "idle" | "active" | "busy";
  lastOrderTime?: string;
}

interface Staff {
  id: string;
  name: string;
  role: "waiter" | "chef" | "cashier" | "admin";
  status: "active" | "inactive";
  joinedAt: string;
}

let menuItems: MenuItem[] = [
  { 
    id: "1", 
    name: { en: "Classic Burger", ar: "برجر كلاسيك" }, 
    description: { en: "Juicy beef patty with lettuce, tomato, and our secret sauce", ar: "قطعة لحم بقري مع خس، طماطم، وصلصتنا السرية" }, 
    price: 14.99, 
    category: { en: "Main Course", ar: "الطبق الرئيسي" }, 
    image: "https://picsum.photos/seed/burger/400/300", 
    available: true,
    tags: ["bestseller"],
    recommendations: ["3", "4"],
    prepTime: 15,
    calories: 850
  },
  { 
    id: "2", 
    name: { en: "Spicy Zinger", ar: "زنجر حار" }, 
    description: { en: "Crispy chicken with spicy mayo and jalapeños", ar: "دجاج مقرمش مع مايونيز حار وهالبينو" }, 
    price: 13.99, 
    category: { en: "Main Course", ar: "الطبق الرئيسي" }, 
    image: "https://picsum.photos/seed/zinger/400/300", 
    available: true,
    tags: ["spicy", "new"],
    recommendations: ["3"],
    prepTime: 12,
    calories: 720
  },
  { 
    id: "3", 
    name: { en: "French Fries", ar: "بطاطس مقلية" }, 
    description: { en: "Golden crispy fries with sea salt", ar: "بطاطس مقلية ذهبية مع ملح البحر" }, 
    price: 4.99, 
    category: { en: "Starters", ar: "المقبلات" }, 
    image: "https://picsum.photos/seed/fries/400/300", 
    available: true,
    tags: ["vegan"],
    prepTime: 5,
    calories: 350
  },
  { 
    id: "4", 
    name: { en: "Coke", ar: "كوكا كولا" }, 
    description: { en: "Chilled 330ml can", ar: "علبة 330 مل مبردة" }, 
    price: 2.50, 
    category: { en: "Drinks", ar: "المشروبات" }, 
    image: "https://picsum.photos/seed/coke/400/300", 
    available: true,
    prepTime: 2
  },
  { 
    id: "5", 
    name: { en: "Quinoa Salad", ar: "سلطة كينوا" }, 
    description: { en: "Fresh quinoa with avocado and lemon dressing", ar: "كينوا طازجة مع أفوكادو وتتبيلة ليمون" }, 
    price: 11.99, 
    category: { en: "Salads", ar: "سلطات" }, 
    image: "https://picsum.photos/seed/salad/400/300", 
    available: true,
    tags: ["vegan", "chef-choice"],
    prepTime: 8,
    calories: 420
  },
];

let orders: Order[] = [];
let tables: Table[] = [
  { id: "table-1", number: "1", status: "idle" },
  { id: "table-2", number: "2", status: "idle" },
  { id: "table-3", number: "3", status: "idle" },
  { id: "table-4", number: "4", status: "idle" },
  { id: "table-5", number: "5", status: "idle" },
];

let staffMembers: Staff[] = [
  { id: "s1", name: "Ahmed Ali", role: "waiter", status: "active", joinedAt: new Date().toISOString() },
  { id: "s2", name: "Sara Khan", role: "chef", status: "active", joinedAt: new Date().toISOString() },
  { id: "s3", name: "John Doe", role: "cashier", status: "active", joinedAt: new Date().toISOString() },
];

// --- WebSocket Clients ---
const clients = new Set<any>();

const broadcast = (data: any) => {
  clients.forEach((client) => {
    if (client.readyState === 1) {
      client.send(JSON.stringify(data));
    }
  });
};

let notifications: any[] = [];

app.ws("/ws", (ws) => {
  clients.add(ws);
  ws.on("close", () => clients.delete(ws));
});

// --- API Routes ---

// Notifications
app.get("/api/notifications", (req, res) => res.json(notifications));
app.post("/api/notifications", (req, res) => {
  const notification = {
    id: uuidv4(),
    type: req.body.type, // 'WAITER_CALL' | 'ORDER_READY'
    tableId: req.body.tableId,
    tableNumber: req.body.tableNumber,
    message: req.body.message,
    status: "unread",
    createdAt: new Date().toISOString(),
  };
  notifications.unshift(notification);
  broadcast({ type: "NEW_NOTIFICATION", notification });
  res.json(notification);
});
app.put("/api/notifications/:id", (req, res) => {
  const index = notifications.findIndex((n) => n.id === req.params.id);
  if (index !== -1) {
    notifications[index] = { ...notifications[index], ...req.body };
    broadcast({ type: "NOTIFICATION_UPDATED", notification: notifications[index] });
    res.json(notifications[index]);
  } else res.status(404).json({ error: "Not found" });
});

// Menu
app.get("/api/menu", (req, res) => {
  const { timeOfDay } = req.query;
  let filtered = menuItems;
  
  if (timeOfDay) {
    // Simple logic: some items might be breakfast only, etc.
    // For now, we'll just return all but this is where the logic would go.
  }
  
  res.json(filtered);
});

// Recommendations: "Customers also ordered"
app.get("/api/recommendations/:itemId", (req, res) => {
  const { itemId } = req.params;
  const associatedItems = new Map<string, number>();
  
  orders.forEach(order => {
    const hasItem = order.items.some(i => i.menuItemId === itemId);
    if (hasItem) {
      order.items.forEach(i => {
        if (i.menuItemId !== itemId) {
          associatedItems.set(i.menuItemId, (associatedItems.get(i.menuItemId) || 0) + 1);
        }
      });
    }
  });
  
  const sorted = Array.from(associatedItems.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([id]) => menuItems.find(m => m.id === id))
    .filter(Boolean);
    
  res.json(sorted);
});

// AI Insights for Admin
app.get("/api/admin/insights", async (req, res) => {
  if (!process.env.GEMINI_API_KEY) {
    return res.json({ 
      suggestions: [
        "Promote 'Classic Burger' - it's your top seller this week.",
        "Consider a combo for 'French Fries' and 'Coke' to increase average order value.",
        "Low sales for 'Quinoa Salad' - try a 'Chef's Choice' tag.",
        "Peak hours are 7 PM - 9 PM. Consider a 'Happy Hour' discount earlier to balance load."
      ] 
    });
  }

  try {
    const model = "gemini-3-flash-preview";
    const prompt = `You are a restaurant business consultant. Analyze this data and provide 4 specific, actionable business insights to increase revenue and efficiency.
    Menu Items: ${JSON.stringify(menuItems.map(m => ({ name: m.name.en, price: m.price, category: m.category.en })))}
    Recent Orders: ${JSON.stringify(orders.slice(-20).map(o => ({ total: o.total, items: o.items.length, time: o.createdAt })))}
    Return ONLY a JSON array of strings. No other text.`;

    const response = await genAI.models.generateContent({
      model,
      contents: [{ parts: [{ text: prompt }] }],
    });

    const text = response.text || "[]";
    const suggestions = JSON.parse(text.substring(text.indexOf("["), text.lastIndexOf("]") + 1));
    res.json({ suggestions });
  } catch (error) {
    res.status(500).json({ error: "Failed to generate insights" });
  }
});

// Analytics for Admin
app.get("/api/admin/analytics", (req, res) => {
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrders = orders.length;
  const activeTables = tables.filter(t => t.status !== "idle").length;
  
  const salesByProductMap = new Map<string, number>();
  
  orders.forEach(o => {
    o.items.forEach(item => {
      const menuItem = menuItems.find(m => m.id === item.menuItemId);
      if (menuItem) {
        const name = menuItem.name.en;
        salesByProductMap.set(name, (salesByProductMap.get(name) || 0) + (item.price * item.quantity));
      }
    });
  });

  const salesByProduct = Array.from(salesByProductMap.entries()).map(([name, revenue]) => ({
    name,
    revenue: parseFloat(revenue.toFixed(2))
  })).sort((a, b) => b.revenue - a.revenue);

  res.json({
    totalRevenue,
    totalOrders,
    activeTables,
    salesByProduct
  });
});

// Staff Management
app.get("/api/staff", (req, res) => res.json(staffMembers));
app.post("/api/staff", (req, res) => {
  const newStaff = { ...req.body, id: uuidv4(), joinedAt: new Date().toISOString() };
  staffMembers.push(newStaff);
  res.json(newStaff);
});
app.put("/api/staff/:id", (req, res) => {
  const index = staffMembers.findIndex(s => s.id === req.params.id);
  if (index !== -1) {
    staffMembers[index] = { ...staffMembers[index], ...req.body };
    res.json(staffMembers[index]);
  } else res.status(404).json({ error: "Staff member not found" });
});
app.delete("/api/staff/:id", (req, res) => {
  staffMembers = staffMembers.filter(s => s.id !== req.params.id);
  res.sendStatus(204);
});

app.post("/api/menu", (req, res) => {
  const newItem = { ...req.body, id: uuidv4() };
  menuItems.push(newItem);
  broadcast({ type: "MENU_UPDATED", menuItems });
  res.json(newItem);
});
app.put("/api/menu/:id", (req, res) => {
  const index = menuItems.findIndex((i) => i.id === req.params.id);
  if (index !== -1) {
    menuItems[index] = { ...menuItems[index], ...req.body };
    broadcast({ type: "MENU_UPDATED", menuItems });
    res.json(menuItems[index]);
  } else res.status(404).json({ error: "Not found" });
});
app.delete("/api/menu/:id", (req, res) => {
  menuItems = menuItems.filter((i) => i.id !== req.params.id);
  broadcast({ type: "MENU_UPDATED", menuItems });
  res.sendStatus(204);
});

// Tables
app.get("/api/tables", (req, res) => res.json(tables));
app.post("/api/tables", (req, res) => {
  const newTable = { ...req.body, id: uuidv4() };
  tables.push(newTable);
  broadcast({ type: "TABLES_UPDATED", tables });
  res.json(newTable);
});

// Orders
app.get("/api/orders", (req, res) => res.json(orders));
app.post("/api/orders", (req, res) => {
  const newOrder: Order = {
    ...req.body,
    id: uuidv4(),
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  orders.push(newOrder);
  
  // Update table status
  const tableIndex = tables.findIndex(t => t.id === newOrder.tableId);
  if (tableIndex !== -1) {
    tables[tableIndex].status = "active";
    tables[tableIndex].lastOrderTime = newOrder.createdAt;
    broadcast({ type: "TABLES_UPDATED", tables });
  }

  broadcast({ type: "NEW_ORDER", order: newOrder });
  res.json(newOrder);
});
app.put("/api/orders/:id", (req, res) => {
  const index = orders.findIndex((o) => o.id === req.params.id);
  if (index !== -1) {
    orders[index] = { ...orders[index], ...req.body };
    broadcast({ type: "ORDER_UPDATED", order: orders[index] });
    res.json(orders[index]);
  } else res.status(404).json({ error: "Not found" });
});

// --- Vite Setup ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
