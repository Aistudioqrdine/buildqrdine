export interface MenuItem {
  id: string;
  name: { en: string; ar: string };
  description: { en: string; ar: string };
  price: number;
  category: { en: string; ar: string };
  image: string;
  available: boolean;
  tags?: ("spicy" | "vegan" | "bestseller" | "new" | "chef-choice")[];
  recommendations?: string[]; // IDs of other menu items
  prepTime?: number; // in minutes
  calories?: number;
}

export interface OrderItem {
  id: string;
  menuItemId: string;
  name: string;
  quantity: number;
  price: number;
  instructions?: string;
  addOns?: { name: string; price: number }[];
}

export interface Order {
  id: string;
  tableId: string;
  tableNumber: string;
  items: OrderItem[];
  status: "pending" | "preparing" | "ready" | "paid";
  total: number;
  createdAt: string;
  customerPhone?: string;
  estimatedReadyTime?: string;
}

export interface Table {
  id: string;
  number: string;
  status: "idle" | "active" | "busy";
  lastOrderTime?: string;
}

export interface Notification {
  id: string;
  type: "WAITER_CALL" | "ORDER_READY" | "BILL_REQUEST";
  tableId: string;
  tableNumber: string;
  message: string;
  status: "unread" | "read";
  createdAt: string;
}
