import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    // We can add translations here if needed
  },
  ar: {
    // We can add translations here if needed
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('app_lang');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('app_lang', lang);
    document.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const t = (key: string) => {
    // Simple translation function, can be expanded
    return key; 
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

// Formatting utilities
export function formatCurrency(amount: number, lang: Language): string {
  return new Intl.NumberFormat(lang === 'ar' ? 'ar-QA' : 'en-QA', {
    style: 'currency',
    currency: 'QAR',
  }).format(amount);
}

export function formatDate(dateString: string | Date, lang: Language): string {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-QA' : 'en-US', {
    dateStyle: 'medium',
  }).format(date);
}

export function formatTime(dateString: string | Date, lang: Language): string {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-QA' : 'en-US', {
    timeStyle: 'short',
  }).format(date);
}

export function formatDateTime(dateString: string | Date, lang: Language): string {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-QA' : 'en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
}
