import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import CustomerMenu from "./pages/CustomerMenu";
import AdminDashboard from "./pages/AdminDashboard";
import KitchenDashboard from "./pages/KitchenDashboard";
import CashierDashboard from "./pages/CashierDashboard";
import WaiterDashboard from "./pages/WaiterDashboard";
import OrderStatus from "./pages/OrderStatus";
import { LanguageProvider } from "./lib/i18n";
import { FirebaseProvider } from "./components/FirebaseProvider";

export default function App() {
  return (
    <FirebaseProvider>
      <LanguageProvider>
        <Router>
          <div className="min-h-screen bg-gray-50 font-sans text-gray-900">
            <Routes>
              <Route path="/" element={<Navigate to="/admin" replace />} />
              <Route path="/table/:tableId" element={<CustomerMenu />} />
              <Route path="/order/:orderId" element={<OrderStatus />} />
              <Route path="/admin/*" element={<AdminDashboard />} />
              <Route path="/kitchen" element={<KitchenDashboard />} />
              <Route path="/cashier" element={<CashierDashboard />} />
              <Route path="/waiter" element={<WaiterDashboard />} />
            </Routes>
            <Toaster position="top-center" richColors />
          </div>
        </Router>
      </LanguageProvider>
    </FirebaseProvider>
  );
}

