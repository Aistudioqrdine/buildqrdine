import React, { useState, useEffect, useMemo, useRef } from "react";
import { Plus, Edit2, Trash2, QrCode, TrendingUp, Users, DollarSign, Package, Check, X, Sparkles, Clock, AlertCircle, Upload, Image as ImageIcon, Loader2 } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from "recharts";
import DashboardLayout from "../components/DashboardLayout";
import { MenuItem, Table, Order } from "../types";
import { cn } from "../lib/utils";
import { useLanguage, formatCurrency } from "../lib/i18n";
import { db, storage, auth } from "../firebase";
import { collection, doc, onSnapshot, setDoc, updateDoc, deleteDoc, addDoc } from "firebase/firestore";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { handleFirestoreError, OperationType } from "../firebase"; // Assuming handleFirestoreError is in firebase.ts or similar
import { v4 as uuidv4 } from "uuid";

export default function AdminDashboard() {
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [staff, setStaff] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<"menu" | "tables" | "staff" | "analytics">("menu");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [editingStaff, setEditingStaff] = useState<any | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { lang } = useLanguage();

  useEffect(() => {
    // Menu Listener
    const unsubscribeMenu = onSnapshot(collection(db, "menu"), (snapshot) => {
      const menuData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MenuItem));
      setMenu(menuData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "menu"));

    // Tables Listener
    const unsubscribeTables = onSnapshot(collection(db, "tables"), (snapshot) => {
      const tablesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Table));
      setTables(tablesData.sort((a, b) => parseInt(a.number) - parseInt(b.number)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, "tables"));

    // Orders Listener
    const unsubscribeOrders = onSnapshot(collection(db, "orders"), (snapshot) => {
      const ordersData = snapshot.docs.map(doc => {
        const data = doc.data();
        return { 
          id: doc.id, 
          ...data,
          total: data.totalPrice, // Map totalPrice to total for compatibility
          createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt 
        } as Order;
      });
      setOrders(ordersData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "orders"));

    // Staff Listener (Users)
    const unsubscribeStaff = onSnapshot(collection(db, "users"), (snapshot) => {
      const staffData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setStaff(staffData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "users"));

    return () => {
      unsubscribeMenu();
      unsubscribeTables();
      unsubscribeOrders();
      unsubscribeStaff();
    };
  }, []);

  const analytics = useMemo(() => {
    const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0);
    const totalOrders = orders.length;
    const activeTablesCount = tables.filter(t => t.status !== "idle").length;
    
    const salesByProductMap = new Map<string, number>();
    orders.forEach(o => {
      o.items.forEach(item => {
        const name = item.name;
        salesByProductMap.set(name, (salesByProductMap.get(name) || 0) + (item.price * item.quantity));
      });
    });

    const salesByProduct = Array.from(salesByProductMap.entries()).map(([name, revenue]) => ({
      name,
      revenue: parseFloat(revenue.toFixed(2))
    })).sort((a, b) => b.revenue - a.revenue);

    return {
      totalRevenue,
      totalOrders,
      activeTables: activeTablesCount,
      salesByProduct
    };
  }, [orders, tables]);

  const stats = useMemo(() => {
    return [
      { label: "Total Revenue", value: formatCurrency(analytics.totalRevenue, lang), icon: DollarSign, color: "text-green-600", bg: "bg-green-50" },
      { label: "Total Orders", value: analytics.totalOrders, icon: Package, color: "text-blue-600", bg: "bg-blue-50" },
      { label: "Active Tables", value: analytics.activeTables, icon: Users, color: "text-orange-600", bg: "bg-orange-50" },
      { label: "Popular Item", value: analytics.salesByProduct[0]?.name || "N/A", icon: TrendingUp, color: "text-purple-600", bg: "bg-purple-50" },
    ];
  }, [analytics, lang]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const storageRef = ref(storage, `menu/${uuidv4()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      setUploadedImageUrl(url);
      toast.success("Image uploaded successfully");
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Failed to upload image");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSaveStaff = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    const staffData = {
      name: formData.get("name") as string,
      role: formData.get("role") as string,
      status: formData.get("status") as string,
      email: formData.get("email") as string,
    };

    try {
      if (editingStaff) {
        await updateDoc(doc(db, "users", editingStaff.id), staffData);
        toast.success("Staff updated");
        setIsStaffModalOpen(false);
        setEditingStaff(null);
      } else {
        const password = formData.get("password") as string;
        const userCredential = await createUserWithEmailAndPassword(auth, staffData.email, password);
        const userId = userCredential.user.uid;
        
        await setDoc(doc(db, "users", userId), {
          ...staffData,
          id: userId,
          joinedAt: new Date().toISOString()
        });
        toast.success("Staff member created");
        setIsStaffModalOpen(false);
      }
    } catch (error) {
      console.error("Staff creation error:", error);
      toast.error("Failed to create staff member");
      handleFirestoreError(error, OperationType.WRITE, "users");
    } finally {
      setIsSaving(false);
    }
  };

  const deleteStaff = async (id: string) => {
    if (!confirm("Are you sure?")) return;
    try {
      await deleteDoc(doc(db, "users", id));
      toast.success("Staff removed");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, "users");
    }
  };

  const handleSaveItem = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    
    const nameEn = formData.get("name_en") as string;
    const nameAr = formData.get("name_ar") as string;
    const price = parseFloat(formData.get("price") as string);
    const categoryEn = formData.get("category_en") as string;
    const categoryAr = formData.get("category_ar") as string;

    if (!nameEn || !nameAr || isNaN(price) || !categoryEn || !categoryAr) {
      toast.error("Please fill in all required fields (Name, Price, Category)");
      setIsSaving(false);
      return;
    }

    const itemData = {
      name: { en: nameEn, ar: nameAr },
      description: { en: formData.get("description_en") as string, ar: formData.get("description_ar") as string },
      price: price,
      category: { en: categoryEn, ar: categoryAr },
      image: uploadedImageUrl || formData.get("image_url") as string || editingItem?.image || "",
      available: formData.get("available") === "on",
    };

    try {
      if (editingItem) {
        await updateDoc(doc(db, "menu", editingItem.id), itemData);
        toast.success("Item updated");
      } else {
        await addDoc(collection(db, "menu"), itemData);
        toast.success("Item added");
      }
      setIsModalOpen(false);
      setEditingItem(null);
      setUploadedImageUrl("");
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "menu");
    } finally {
      setIsSaving(false);
    }
  };

  const toggleAvailability = async (item: MenuItem) => {
    try {
      await updateDoc(doc(db, "menu", item.id), { available: !item.available });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "menu");
    }
  };

  const deleteItem = async (id: string) => {
    if (!confirm("Are you sure you want to delete this item?")) return;
    try {
      await deleteDoc(doc(db, "menu", id));
      toast.success("Item deleted");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, "menu");
    }
  };

  return (
    <DashboardLayout title="Admin Dashboard">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border dark:border-zinc-800 shadow-sm flex items-center gap-4">
            <div className={cn("p-3 rounded-xl", stat.bg, stat.color, "dark:bg-opacity-20")}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-zinc-400 font-medium">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-zinc-900 rounded-2xl border dark:border-zinc-800 shadow-sm overflow-hidden">
        <div className="border-b dark:border-zinc-800 px-4 sm:px-8 py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between bg-gray-50/50 dark:bg-zinc-800/50 gap-4">
          <div className="flex gap-2 sm:gap-4 overflow-x-auto w-full sm:w-auto pb-2 sm:pb-0 scrollbar-hide">
            {["menu", "tables", "staff", "analytics"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-bold capitalize transition-all whitespace-nowrap",
                  activeTab === tab
                    ? "bg-white dark:bg-zinc-900 text-orange-600 shadow-sm border dark:border-zinc-700"
                    : "text-gray-500 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                {tab}
              </button>
            ))}
          </div>
          {activeTab === "menu" && (
            <button
              onClick={() => { setEditingItem(null); setIsModalOpen(true); }}
              className="bg-orange-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-orange-700 transition-colors w-full sm:w-auto justify-center"
            >
              <Plus size={18} />
              Add Item
            </button>
          )}
          {activeTab === "staff" && (
            <button
              onClick={() => { setEditingStaff(null); setIsStaffModalOpen(true); }}
              className="bg-orange-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-orange-700 transition-colors w-full sm:w-auto justify-center"
            >
              <Plus size={18} />
              Add Staff
            </button>
          )}
        </div>

        <div className="p-4 sm:p-8">
          {activeTab === "menu" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {menu.map((item) => (
                <div key={item.id} className="border dark:border-zinc-800 rounded-2xl p-4 flex gap-4 group hover:border-orange-200 dark:hover:border-orange-900/50 transition-colors bg-white dark:bg-zinc-900">
                  <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-gray-100 dark:bg-zinc-800">
                    <img src={item.image} alt={item.name.en} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex-grow flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-gray-900 dark:text-white">{item.name.en} / {item.name.ar}</h4>
                        <span className="text-sm font-bold text-orange-600">{formatCurrency(item.price, lang)}</span>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-zinc-400 line-clamp-1">{item.description.en} / {item.description.ar}</p>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <button
                        onClick={() => toggleAvailability(item)}
                        className={cn(
                          "text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-wider transition-colors",
                          item.available ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400" : "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"
                        )}
                      >
                        {item.available ? "In Stock" : "Out of Stock"}
                      </button>
                      <div className="flex gap-2">
                        <button
                          onClick={() => { setEditingItem(item); setIsModalOpen(true); }}
                          className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button
                          onClick={() => deleteItem(item.id)}
                          className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "tables" && (
            <div className="space-y-10">
              {/* Table Heatmap */}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Table Heatmap</h3>
                    <p className="text-sm text-gray-500 dark:text-zinc-400 text-balance">Real-time occupancy and activity status</p>
                  </div>
                  <div className="flex gap-4 text-xs font-bold uppercase tracking-wider">
                    <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-green-500" /> Available</div>
                    <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-orange-500" /> Occupied</div>
                    <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-500" /> Needs Attention</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {tables.map((table) => {
                    const tableOrders = orders.filter(o => o.tableId === table.id && o.status !== "paid");
                    const isOccupied = tableOrders.length > 0;
                    const needsAttention = tableOrders.some(o => o.status === "ready");
                    
                    return (
                      <motion.div
                        key={table.id}
                        whileHover={{ scale: 1.02 }}
                        className={cn(
                          "aspect-square rounded-3xl border-2 p-4 flex flex-col items-center justify-center relative overflow-hidden transition-all",
                          needsAttention ? "border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/20" : 
                          isOccupied ? "border-orange-200 dark:border-orange-900/50 bg-orange-50 dark:bg-orange-900/20" : 
                          "border-green-100 dark:border-green-900/20 bg-green-50/30 dark:bg-green-900/10"
                        )}
                      >
                        <div className={cn(
                          "absolute top-3 right-3 w-3 h-3 rounded-full",
                          needsAttention ? "bg-red-500 animate-pulse" : 
                          isOccupied ? "bg-orange-500" : 
                          "bg-green-500"
                        )} />
                        <span className="text-3xl font-black text-gray-900 dark:text-white mb-1">{table.number}</span>
                        <span className="text-[10px] font-bold uppercase text-gray-500 dark:text-zinc-400">
                          {needsAttention ? "Ready to Serve" : isOccupied ? "Dining" : "Available"}
                        </span>
                        {isOccupied && (
                          <div className="mt-2 flex items-center gap-1 text-[10px] font-bold text-orange-600">
                            <Clock size={10} />
                            {Math.floor(Math.random() * 45) + 5}m
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Table Management */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {tables.map((table) => (
                  <div key={table.id} className="border dark:border-zinc-800 rounded-2xl p-6 flex flex-col items-center text-center group hover:border-orange-200 dark:hover:border-orange-900/50 transition-colors bg-white dark:bg-zinc-900">
                    <div className="bg-orange-50 dark:bg-orange-900/20 p-4 rounded-2xl mb-4 group-hover:scale-105 transition-transform">
                      <QRCodeSVG
                        value={`${window.location.origin}/table/${table.id}`}
                        size={120}
                        level="H"
                        includeMargin={true}
                        bgColor={localStorage.getItem("theme") === "dark" ? "#18181b" : "#ffffff"}
                        fgColor={localStorage.getItem("theme") === "dark" ? "#ffffff" : "#000000"}
                      />
                    </div>
                    <h4 className="text-lg font-bold text-gray-900 dark:text-white">Table {table.number}</h4>
                    <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1">ID: {table.id}</p>
                    <div className="flex gap-4 mt-4">
                      <button
                        onClick={() => {
                          const url = `${window.location.origin}/table/${table.id}`;
                          window.open(url, "_blank");
                        }}
                        className="text-sm font-bold text-orange-600 hover:underline"
                      >
                        Open Menu
                      </button>
                      <button className="text-sm font-bold text-gray-400 dark:text-zinc-500 hover:text-red-600">Delete</button>
                    </div>
                  </div>
                ))}
                <button
                  onClick={async () => {
                    const number = (tables.length + 1).toString();
                    await setDoc(doc(db, "tables", uuidv4()), {
                      number,
                      status: "idle",
                      qrCodeUrl: ""
                    });
                    toast.success(`Table ${number} added`);
                  }}
                  className="border-2 border-dashed dark:border-zinc-800 rounded-2xl p-6 flex flex-col items-center justify-center text-gray-400 dark:text-zinc-600 hover:text-orange-600 hover:border-orange-200 dark:hover:border-orange-900/50 hover:bg-orange-50 dark:hover:bg-orange-900/10 transition-all min-h-[280px]"
                >
                  <Plus size={32} className="mb-2" />
                  <span className="font-bold">Add New Table</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === "staff" && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {staff.map((member) => (
                <div key={member.id} className="border dark:border-zinc-800 rounded-2xl p-6 flex flex-col gap-4 bg-white dark:bg-zinc-900 hover:border-orange-200 dark:hover:border-orange-900/50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-orange-600 font-bold text-xl">
                      {member.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 dark:text-white">{member.name}</h4>
                      <p className="text-xs text-gray-500 dark:text-zinc-400 capitalize">{member.role}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={cn(
                      "text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-wider",
                      member.status === "active" ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400" : "bg-gray-100 dark:bg-zinc-800 text-gray-700 dark:text-zinc-400"
                    )}>
                      {member.status}
                    </span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => { setEditingStaff(member); setIsStaffModalOpen(true); }}
                        className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button
                        onClick={() => deleteStaff(member.id)}
                        className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "analytics" && (
            <div className="space-y-10">
              {/* Charts Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Sales by Product */}
                <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border dark:border-zinc-800 shadow-sm">
                  <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Sales by Product</h4>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analytics?.salesByProduct || []}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={localStorage.getItem("theme") === "dark" ? "#27272a" : "#f0f0f0"} />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 600, fill: localStorage.getItem("theme") === "dark" ? "#9ca3af" : "#6b7280" }} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600, fill: localStorage.getItem("theme") === "dark" ? "#9ca3af" : "#6b7280" }} />
                        <Tooltip 
                          cursor={{ fill: localStorage.getItem("theme") === "dark" ? "#27272a" : "#f8f9fa" }}
                          contentStyle={{ 
                            borderRadius: '16px', 
                            border: 'none', 
                            boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                            backgroundColor: localStorage.getItem("theme") === "dark" ? "#18181b" : "#ffffff",
                            color: localStorage.getItem("theme") === "dark" ? "#ffffff" : "#000000"
                          }}
                        />
                        <Bar dataKey="revenue" radius={[6, 6, 0, 0]}>
                          {(analytics?.salesByProduct || []).map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={['#f97316', '#3b82f6', '#8b5cf6', '#10b981', '#f43f5e'][index % 5]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Popular Items Pie */}
                <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border dark:border-zinc-800 shadow-sm">
                  <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Popular Items</h4>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={analytics?.salesByProduct?.map((p: any) => ({ name: p.name, value: p.revenue })) || []}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {(analytics?.salesByProduct || []).map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={['#f97316', '#3b82f6', '#8b5cf6', '#10b981', '#f43f5e'][index % 5]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ 
                            borderRadius: '16px', 
                            border: 'none', 
                            boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                            backgroundColor: localStorage.getItem("theme") === "dark" ? "#18181b" : "#ffffff",
                            color: localStorage.getItem("theme") === "dark" ? "#ffffff" : "#000000"
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Table Heatmap */}
              <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border dark:border-zinc-800 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h4 className="text-lg font-bold text-gray-900 dark:text-white">Table Occupancy Heatmap</h4>
                    <p className="text-sm text-gray-500 dark:text-zinc-400">Real-time status of your dining area</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full" />
                      <span className="text-[10px] font-black text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Available</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full" />
                      <span className="text-[10px] font-black text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Occupied</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full" />
                      <span className="text-[10px] font-black text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Needs Attention</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
                  {tables.map((table) => {
                    const tableOrders = orders.filter(o => o.tableId === table.id && o.status !== "paid");
                    const isOccupied = tableOrders.length > 0;
                    const needsAttention = tableOrders.some(o => o.status === "ready");
                    
                    return (
                      <motion.div
                        key={table.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={cn(
                          "aspect-square rounded-3xl flex flex-col items-center justify-center gap-1 border-2 transition-all",
                          needsAttention ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 shadow-lg shadow-red-100 dark:shadow-none" :
                          isOccupied ? "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-900/50 text-blue-600 dark:text-blue-400" :
                          "bg-gray-50 dark:bg-zinc-800/50 border-gray-100 dark:border-zinc-800 text-gray-400 dark:text-zinc-500"
                        )}
                      >
                        <span className="text-2xl font-black">{table.number}</span>
                        <span className="text-[8px] font-black uppercase tracking-tighter">
                          {needsAttention ? "Ready" : isOccupied ? "Busy" : "Free"}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Detailed Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-orange-50 dark:bg-orange-900/10 p-6 rounded-3xl border border-orange-100 dark:border-orange-900/20">
                  <div className="flex items-center gap-3 mb-2">
                    <AlertCircle size={18} className="text-orange-600" />
                    <span className="text-sm font-bold text-orange-900 dark:text-orange-400 uppercase tracking-wider">Inventory Alert</span>
                  </div>
                  <p className="text-xs text-orange-700 dark:text-orange-300/70 font-medium">3 items are currently out of stock. Consider restocking soon.</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-3xl border border-blue-100 dark:border-blue-900/20">
                  <div className="flex items-center gap-3 mb-2">
                    <TrendingUp size={18} className="text-blue-600" />
                    <span className="text-sm font-bold text-blue-900 dark:text-blue-400 uppercase tracking-wider">Growth Trend</span>
                  </div>
                  <p className="text-xs text-blue-700 dark:text-blue-300/70 font-medium">Sales are up 12% compared to last week. Great job!</p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/10 p-6 rounded-3xl border border-purple-100 dark:border-purple-900/20">
                  <div className="flex items-center gap-3 mb-2">
                    <Users size={18} className="text-purple-600" />
                    <span className="text-sm font-bold text-purple-900 dark:text-purple-400 uppercase tracking-wider">Customer Loyalty</span>
                  </div>
                  <p className="text-xs text-purple-700 dark:text-purple-300/70 font-medium">15 new customers joined the loyalty program today.</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="fixed inset-0 bg-black/40 z-[60] backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed inset-0 m-auto w-full max-w-lg h-fit bg-white dark:bg-zinc-900 rounded-3xl z-[70] p-8 shadow-2xl border dark:border-zinc-800"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold dark:text-white">{editingItem ? "Edit Item" : "Add New Item"}</h3>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full dark:text-zinc-400">
                  <X size={20} />
                </button>
              </div>
              <form onSubmit={handleSaveItem} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Name (EN)</label>
                    <input name="name_en" defaultValue={editingItem?.name.en} required className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Name (AR)</label>
                    <input name="name_ar" defaultValue={editingItem?.name.ar} required dir="rtl" className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Category (EN)</label>
                    <input name="category_en" defaultValue={editingItem?.category.en} required className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Category (AR)</label>
                    <input name="category_ar" defaultValue={editingItem?.category.ar} required dir="rtl" className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Price</label>
                  <input name="price" type="number" step="0.01" defaultValue={editingItem?.price} required className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Description (EN)</label>
                    <textarea name="description_en" defaultValue={editingItem?.description.en} rows={2} className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none resize-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Description (AR)</label>
                    <textarea name="description_ar" defaultValue={editingItem?.description.ar} rows={2} dir="rtl" className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none resize-none" />
                  </div>
                </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Image</label>
                    <div className="flex flex-col gap-2">
                      <div className="flex gap-2">
                        <input 
                          name="image_url" 
                          defaultValue={editingItem?.image} 
                          placeholder="Paste image URL..."
                          className="flex-grow px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none text-sm" 
                        />
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-4 py-2 bg-gray-100 dark:bg-zinc-800 text-gray-700 dark:text-zinc-300 rounded-xl hover:bg-gray-200 dark:hover:bg-zinc-700 transition-colors flex items-center gap-2 text-sm font-bold"
                        >
                          <Upload size={16} />
                          Upload
                        </button>
                      </div>
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleImageUpload}
                        accept="image/*"
                        className="hidden"
                      />
                      {(uploadedImageUrl || editingItem?.image) && (
                        <div className="relative w-20 h-20 rounded-xl overflow-hidden border dark:border-zinc-800">
                          <img 
                            src={uploadedImageUrl || editingItem?.image} 
                            alt="Preview" 
                            className="w-full h-full object-cover"
                          />
                          {isUploading && (
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                              <Loader2 className="h-5 w-5 animate-spin text-white" />
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                <div className="flex items-center gap-2 pt-2">
                  <input type="checkbox" name="available" id="available" defaultChecked={editingItem?.available ?? true} className="w-4 h-4 accent-orange-600" />
                  <label htmlFor="available" className="text-sm font-medium dark:text-zinc-300">Available for ordering</label>
                </div>
                <button type="submit" disabled={isSaving} className="w-full bg-orange-600 text-white py-3 rounded-xl font-bold mt-4 hover:bg-orange-700 transition-colors disabled:opacity-50">
                  {isSaving ? "Saving..." : editingItem ? "Update Item" : "Create Item"}
                </button>
              </form>
            </motion.div>
          </>
        )}

        {isStaffModalOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsStaffModalOpen(false)}
              className="fixed inset-0 bg-black/40 z-[60] backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed inset-0 m-auto w-full max-w-md h-fit bg-white dark:bg-zinc-900 rounded-3xl z-[70] p-8 shadow-2xl border dark:border-zinc-800"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold dark:text-white">{editingStaff ? "Edit Staff" : "Add Staff Member"}</h3>
                <button onClick={() => setIsStaffModalOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full dark:text-zinc-400">
                  <X size={20} />
                </button>
              </div>
              <form onSubmit={handleSaveStaff} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Full Name</label>
                  <input name="name" defaultValue={editingStaff?.name} required className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                </div>
                {!editingStaff && (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Email</label>
                      <input name="email" type="email" required className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Password</label>
                      <input name="password" type="password" required className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none" />
                    </div>
                  </>
                )}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Role</label>
                  <select name="role" defaultValue={editingStaff?.role || "waiter"} className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none">
                    <option value="waiter">Waiter</option>
                    <option value="chef">Chef</option>
                    <option value="cashier">Cashier</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Status</label>
                  <select name="status" defaultValue={editingStaff?.status || "active"} className="w-full px-4 py-2 rounded-xl border dark:border-zinc-800 bg-white dark:bg-zinc-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                <button type="submit" disabled={isSaving} className="w-full bg-orange-600 text-white py-3 rounded-xl font-bold mt-4 hover:bg-orange-700 transition-colors disabled:opacity-50">
                  {isSaving ? "Saving..." : editingStaff ? "Update Staff" : "Add Staff"}
                </button>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </DashboardLayout>
  );
}
