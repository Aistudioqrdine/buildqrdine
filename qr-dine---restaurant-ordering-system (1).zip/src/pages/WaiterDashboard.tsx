import { useState, useEffect, useMemo } from "react";
import { Bell, Check, Clock, User, Utensils, LayoutGrid, Coffee, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import DashboardLayout from "../components/DashboardLayout";
import { Notification, Table, Order } from "../types";
import { cn } from "../lib/utils";
import { useLanguage, formatCurrency, formatTime } from "../lib/i18n";
import { db } from "../firebase";
import { collection, onSnapshot, query, orderBy, updateDoc, doc, Timestamp } from "firebase/firestore";
import { handleFirestoreError, OperationType } from "../firebase";

export default function WaiterDashboard() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const { lang } = useLanguage();

  const [isShiftSummaryOpen, setIsShiftSummaryOpen] = useState(false);

  useEffect(() => {
    // Real-time notifications
    const qNotifications = query(collection(db, "notifications"), orderBy("createdAt", "desc"));
    const unsubscribeNotifications = onSnapshot(qNotifications, (snapshot) => {
      const notifs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification));
      
      // Check for new unread notifications to trigger toast/sound
      const newUnread = notifs.filter(n => n.status === "unread");
      if (newUnread.length > notifications.filter(n => n.status === "unread").length) {
        const latest = newUnread[0];
        toast.info(latest.message, {
          icon: <Bell className="text-orange-600" />,
          duration: 5000,
        });
        const audio = new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");
        audio.play().catch(() => {});
      }
      
      setNotifications(notifs);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "notifications");
    });

    // Real-time tables
    const unsubscribeTables = onSnapshot(collection(db, "tables"), (snapshot) => {
      setTables(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Table)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "tables");
    });

    // Real-time orders
    const unsubscribeOrders = onSnapshot(collection(db, "orders"), (snapshot) => {
      setOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "orders");
    });

    return () => {
      unsubscribeNotifications();
      unsubscribeTables();
      unsubscribeOrders();
    };
  }, [notifications.length]);

  const markAsRead = async (id: string) => {
    try {
      await updateDoc(doc(db, "notifications", id), {
        status: "read",
        updatedAt: Timestamp.now()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `notifications/${id}`);
      toast.error("Failed to update notification");
    }
  };

  const unreadNotifications = notifications.filter((n) => n.status === "unread");
  const readNotifications = notifications.filter((n) => n.status === "read");

  const updateTableStatus = async (tableId: string, status: Table["status"]) => {
    try {
      await updateDoc(doc(db, "tables", tableId), {
        status,
        updatedAt: Timestamp.now()
      });
      toast.success(`Table status updated to ${status}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `tables/${tableId}`);
      toast.error("Failed to update table status");
    }
  };

  const shiftStats = useMemo(() => {
    const servedOrders = orders.filter(o => o.status === "paid");
    const totalTips = servedOrders.length * 2.5; // Simulated tips
    return {
      orders: servedOrders.length,
      tips: totalTips,
      hours: "6.5",
      performance: "98%"
    };
  }, [orders]);

  return (
    <DashboardLayout title="Waiter Dashboard">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Alerts */}
        <div className="lg:col-span-2 space-y-8">
          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-orange-100 dark:bg-orange-900/30 p-2 rounded-lg text-orange-600">
                <Bell size={20} />
              </div>
              <h3 className="text-xl font-bold dark:text-white">Active Alerts</h3>
              <span className="bg-orange-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                {unreadNotifications.length}
              </span>
            </div>

            <div className="grid gap-4">
              <AnimatePresence mode="popLayout">
                {unreadNotifications.length === 0 ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-white dark:bg-zinc-900 border dark:border-zinc-800 rounded-2xl p-12 text-center text-gray-400 dark:text-zinc-500"
                  >
                    <Bell size={48} className="mx-auto mb-4 opacity-20" />
                    <p className="font-medium">No active alerts</p>
                  </motion.div>
                ) : (
                  unreadNotifications.map((n) => (
                    <motion.div
                      layout
                      key={n.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className={cn(
                        "bg-white dark:bg-zinc-900 border-2 rounded-2xl p-6 shadow-sm flex items-center justify-between",
                        n.type === "WAITER_CALL" ? "border-orange-200 dark:border-orange-900/50 bg-orange-50/30 dark:bg-orange-900/10" : "border-green-200 dark:border-green-900/50 bg-green-50/30 dark:bg-green-900/10"
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-xl",
                          n.type === "WAITER_CALL" ? "bg-orange-600" : "bg-green-600"
                        )}>
                          {n.tableNumber}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900 dark:text-white">{n.message}</p>
                          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-zinc-400 mt-1">
                            <Clock size={12} />
                            <span>{formatTime(n.createdAt, lang)}</span>
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => markAsRead(n.id)}
                        className="bg-white dark:bg-zinc-800 border-2 border-gray-100 dark:border-zinc-700 text-gray-600 dark:text-zinc-300 p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-zinc-700 hover:border-gray-200 dark:hover:border-zinc-600 transition-all"
                      >
                        <Check size={20} />
                      </button>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>
          </section>

          {/* History */}
          {readNotifications.length > 0 && (
            <section>
              <h3 className="text-lg font-bold text-gray-500 dark:text-zinc-400 mb-4">Recent History</h3>
              <div className="bg-white dark:bg-zinc-900 border dark:border-zinc-800 rounded-2xl overflow-hidden">
                <div className="divide-y dark:divide-zinc-800">
                  {readNotifications.slice(0, 5).map((n) => (
                    <div key={n.id} className="p-4 flex items-center justify-between opacity-60">
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-lg bg-gray-100 dark:bg-zinc-800 flex items-center justify-center text-gray-500 dark:text-zinc-400 font-bold text-sm">
                          {n.tableNumber}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900 dark:text-white">{n.message}</p>
                          <p className="text-xs text-gray-500 dark:text-zinc-500">{formatTime(n.createdAt, lang)}</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-gray-400 dark:text-zinc-500 uppercase">Resolved</span>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}
        </div>

        {/* Right Column: Table Status Overview */}
        <div className="space-y-8">
          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-lg text-blue-600">
                <LayoutGrid size={20} />
              </div>
              <h3 className="text-xl font-bold dark:text-white">Table Status</h3>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {tables.map((table) => {
                const tableOrders = orders.filter(o => o.tableId === table.id && o.status !== "paid");
                const isOccupied = tableOrders.length > 0;
                const needsAttention = tableOrders.some(o => o.status === "ready");
                const isCalling = notifications.some(n => n.tableId === table.id && n.status === "unread" && n.type === "WAITER_CALL");

                return (
                  <motion.div
                    key={table.id}
                    className={cn(
                      "p-4 rounded-3xl border-2 transition-all",
                      isCalling ? "border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/10 animate-pulse" :
                      needsAttention ? "border-green-200 dark:border-green-900/50 bg-green-50 dark:bg-green-900/10" :
                      isOccupied ? "border-blue-100 dark:border-blue-900/50 bg-blue-50/30 dark:bg-blue-900/10" :
                      "border-gray-100 dark:border-zinc-800 bg-white dark:bg-zinc-900"
                    )}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xl font-black text-gray-900 dark:text-white">{table.number}</span>
                      {isCalling && <AlertCircle size={16} className="text-red-500" />}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          isCalling ? "bg-red-500" :
                          needsAttention ? "bg-green-500" :
                          isOccupied ? "bg-blue-500" :
                          "bg-gray-300 dark:bg-zinc-700"
                        )} />
                        <span className="text-[10px] font-bold uppercase text-gray-500 dark:text-zinc-400">
                          {isCalling ? "Calling" : needsAttention ? "Ready" : isOccupied ? "Busy" : "Free"}
                        </span>
                      </div>

                      {isOccupied && (
                        <button
                          onClick={() => updateTableStatus(table.id, "idle")}
                          className="w-full mt-2 py-1.5 bg-white dark:bg-zinc-800 border border-gray-100 dark:border-zinc-700 rounded-xl text-[10px] font-bold text-gray-500 dark:text-zinc-400 hover:text-orange-600 dark:hover:text-orange-400 hover:border-orange-100 dark:hover:border-orange-900/50 transition-all"
                        >
                          Clear Table
                        </button>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </section>

          {/* Quick Actions */}
          <section className="bg-gray-900 dark:bg-zinc-900 rounded-3xl p-6 text-white border dark:border-zinc-800">
            <h4 className="text-sm font-bold mb-4 uppercase tracking-widest text-gray-400 dark:text-zinc-500">Quick Actions</h4>
            <div className="grid gap-3">
              <button className="w-full bg-white/10 hover:bg-white/20 py-3 rounded-2xl text-sm font-bold flex items-center justify-center gap-3 transition-all">
                <Coffee size={18} />
                Break Time
              </button>
              <button 
                onClick={() => setIsShiftSummaryOpen(true)}
                className="w-full bg-white/10 hover:bg-white/20 py-3 rounded-2xl text-sm font-bold flex items-center justify-center gap-3 transition-all"
              >
                <User size={18} />
                Shift Summary
              </button>
            </div>
          </section>
        </div>
      </div>

      {/* Shift Summary Modal */}
      <AnimatePresence>
        {isShiftSummaryOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsShiftSummaryOpen(false)}
              className="fixed inset-0 bg-black/60 z-[60] backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed inset-0 m-auto w-full max-w-sm h-fit bg-white dark:bg-zinc-900 rounded-[40px] z-[70] p-8 shadow-2xl border dark:border-zinc-800"
            >
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-orange-100 dark:bg-orange-900/30 text-orange-600 rounded-[32px] flex items-center justify-center mx-auto mb-4">
                  <User size={40} />
                </div>
                <h3 className="text-2xl font-black text-gray-900 dark:text-white">Shift Summary</h3>
                <p className="text-sm text-gray-500 dark:text-zinc-400">Great job today, Omar!</p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Orders Served</p>
                  <p className="text-xl font-black text-gray-900 dark:text-white">{shiftStats.orders}</p>
                </div>
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Estimated Tips</p>
                  <p className="text-xl font-black text-green-600">{formatCurrency(shiftStats.tips, lang)}</p>
                </div>
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Hours Worked</p>
                  <p className="text-xl font-black text-gray-900 dark:text-white">{shiftStats.hours}h</p>
                </div>
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Performance</p>
                  <p className="text-xl font-black text-blue-600">{shiftStats.performance}</p>
                </div>
              </div>

              <button
                onClick={() => setIsShiftSummaryOpen(false)}
                className="w-full bg-gray-900 dark:bg-zinc-800 text-white py-4 rounded-2xl font-bold hover:bg-gray-800 dark:hover:bg-zinc-700 transition-all"
              >
                Close Summary
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </DashboardLayout>
  );
}
