import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { CheckCircle2, Clock, ChefHat, CreditCard, ChevronLeft, Bell, MapPin, Moon, Sun } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { Order } from "../types";
import { cn } from "../lib/utils";
import { useLanguage, formatCurrency, formatTime } from "../lib/i18n";
import { db } from "../firebase";
import { doc, onSnapshot, addDoc, collection, serverTimestamp } from "firebase/firestore";

export default function OrderStatus() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [isCallingWaiter, setIsCallingWaiter] = useState(false);
  const { lang, setLang } = useLanguage();
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem("theme") === "dark";
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDarkMode]);

  useEffect(() => {
    const handleStorageChange = () => {
      setIsDarkMode(localStorage.getItem("theme") === "dark");
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  useEffect(() => {
    if (!orderId) return;

    const unsub = onSnapshot(doc(db, "orders", orderId), (doc) => {
      if (doc.exists()) {
        const data = doc.data() as Order;
        setOrder({ ...data, id: doc.id });
        if (data.status === "ready" && order?.status !== "ready") {
          toast.success("Your order is ready!", { duration: 5000 });
        }
      } else {
        setOrder(null);
      }
      setLoading(false);
    }, (error) => {
      console.error("Error fetching order status:", error);
      toast.error("Failed to fetch order status");
      setLoading(false);
    });

    return () => unsub();
  }, [orderId, order?.status]);

  const callWaiter = async () => {
    if (isCallingWaiter || !order) return;
    setIsCallingWaiter(true);
    try {
      await addDoc(collection(db, "notifications"), {
        type: "WAITER_CALL",
        tableId: order.tableId,
        tableNumber: order.tableNumber,
        message: `Table ${order.tableNumber} needs assistance with order #${order.id.slice(-4)}`,
        status: "unread",
        createdAt: serverTimestamp(),
      });
      toast.success("Waiter notified!");
    } catch (error) {
      console.error("Error notifying waiter:", error);
      toast.error("Failed to notify waiter");
    } finally {
      setTimeout(() => setIsCallingWaiter(false), 30000);
    }
  };

  const requestBill = async () => {
    if (!order) return;
    try {
      await addDoc(collection(db, "notifications"), {
        type: "BILL_REQUEST",
        tableId: order.tableId,
        tableNumber: order.tableNumber,
        message: `Table ${order.tableNumber} requested the bill for order #${order.id.slice(-4)}`,
        status: "unread",
        createdAt: serverTimestamp(),
      });
      toast.success("Bill request sent to cashier!");
    } catch (error) {
      console.error("Error requesting bill:", error);
      toast.error("Failed to request bill");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50 dark:bg-black">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
          className="rounded-full h-12 w-12 border-4 border-orange-500 border-t-transparent"
        />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex flex-col items-center justify-center h-screen p-8 text-center bg-gray-50 dark:bg-black">
        <div className="w-24 h-24 bg-white dark:bg-zinc-900 rounded-[40px] shadow-xl flex items-center justify-center text-gray-300 dark:text-zinc-700 mb-8">
          <Clock size={48} />
        </div>
        <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-4">Order Not Found</h2>
        <button
          onClick={() => navigate("/")}
          className="bg-orange-600 text-white px-10 py-4 rounded-2xl font-bold shadow-lg shadow-orange-100 dark:shadow-none"
        >
          Return to Menu
        </button>
      </div>
    );
  }

  const steps = [
    { status: "pending", label: "Order Received", icon: Clock, desc: "We've received your order and it will be processed soon." },
    { status: "preparing", label: "Preparing", icon: ChefHat, desc: "Our chefs are working their magic!" },
    { status: "ready", label: "Ready to Serve", icon: CheckCircle2, desc: "Your food is ready! A waiter will bring it to you shortly." },
    { status: "paid", label: "Completed", icon: CreditCard, desc: "Thank you for dining with us!" },
  ];

  const currentStepIndex = steps.findIndex((s) => s.status === order.status);

  return (
    <div className="max-w-md md:max-w-2xl lg:max-w-3xl mx-auto bg-gray-50 dark:bg-black min-h-screen p-8 font-sans transition-colors duration-300" dir={lang === "ar" ? "rtl" : "ltr"}>
      <header className="flex items-center justify-between mb-12">
        <button
          onClick={() => navigate(-1)}
          className="w-12 h-12 bg-white dark:bg-zinc-900 rounded-2xl flex items-center justify-center text-gray-400 shadow-sm hover:text-gray-900 dark:hover:text-white transition-all"
        >
          <ChevronLeft size={24} className={lang === "ar" ? "rotate-180" : ""} />
        </button>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="w-12 h-12 bg-white dark:bg-zinc-900 rounded-2xl flex items-center justify-center text-gray-400 shadow-sm hover:text-gray-900 dark:hover:text-white transition-all"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button
            onClick={() => setLang(lang === "en" ? "ar" : "en")}
            className="px-3 py-1.5 bg-gray-200 dark:bg-zinc-800 rounded-full text-[10px] font-black uppercase tracking-wider hover:bg-gray-300 dark:hover:bg-zinc-700 transition-all text-gray-600 dark:text-zinc-400"
          >
            {lang === "en" ? "العربية" : "English"}
          </button>
          <div className={lang === "ar" ? "text-left" : "text-right"}>
            <h1 className="text-xl font-black text-gray-900 dark:text-white leading-none">Live Tracking</h1>
            <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mt-1">Order #{order.id.slice(-6).toUpperCase()}</p>
          </div>
        </div>
      </header>

      {/* Estimated Time Card */}
      {order.status !== "paid" && (
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-orange-600 rounded-[40px] p-8 text-white shadow-2xl shadow-orange-100 dark:shadow-none mb-12 relative overflow-hidden"
        >
          <div className="relative z-10">
            <p className="text-xs font-bold uppercase tracking-widest text-white/70">Estimated Ready Time</p>
            <h2 className="text-5xl font-black mt-2">
              {order.estimatedReadyTime ? formatTime(order.estimatedReadyTime, lang) : "--:--"}
            </h2>
            <div className="flex items-center gap-2 mt-6 bg-white/20 w-fit px-4 py-2 rounded-2xl backdrop-blur-md">
              <MapPin size={16} />
              <span className="text-xs font-bold">Table {order.tableNumber}</span>
            </div>
          </div>
          <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-white/10 rounded-full blur-3xl" />
          <Clock className="absolute right-6 top-6 text-white/10" size={140} />
        </motion.div>
      )}

      {/* Tracking Steps */}
      <div className="space-y-10 relative">
        <div className="absolute left-[23px] top-6 bottom-6 w-1 bg-gray-100 dark:bg-zinc-800 rounded-full overflow-hidden">
          <motion.div 
            initial={{ height: 0 }}
            animate={{ height: `${(currentStepIndex / (steps.length - 1)) * 100}%` }}
            className="w-full bg-orange-600 transition-all duration-1000"
          />
        </div>
        
        {steps.map((step, index) => {
          const isCompleted = index < currentStepIndex;
          const isActive = index === currentStepIndex;
          const Icon = step.icon;

          return (
            <div key={step.status} className="flex items-start gap-8 relative">
              <div
                className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center z-10 transition-all duration-700 shadow-sm",
                  isCompleted || isActive
                    ? "bg-orange-600 text-white shadow-orange-100 dark:shadow-none scale-110"
                    : "bg-white dark:bg-zinc-900 text-gray-300 dark:text-zinc-700"
                )}
              >
                <Icon size={24} strokeWidth={isActive ? 3 : 2} />
              </div>
              <div className="flex-grow pt-1">
                <h3
                  className={cn(
                    "font-black tracking-tight transition-all duration-700",
                    isActive ? "text-gray-900 dark:text-white text-xl" : "text-gray-400 dark:text-zinc-500 text-lg"
                  )}
                >
                  {step.label}
                </h3>
                <AnimatePresence>
                  {isActive && (
                    <motion.p
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="text-xs text-gray-400 dark:text-zinc-500 font-medium mt-2 leading-relaxed"
                    >
                      {step.desc}
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </div>
          );
        })}
      </div>

      {/* Actions */}
      <div className="mt-16 grid grid-cols-2 gap-4">
        <button
          onClick={callWaiter}
          disabled={isCallingWaiter}
          className={cn(
            "flex flex-col items-center justify-center gap-3 p-6 rounded-[32px] transition-all border-2",
            isCallingWaiter 
              ? "bg-gray-100 dark:bg-zinc-800 border-gray-100 dark:border-zinc-800 text-gray-400" 
              : "bg-white dark:bg-zinc-900 border-white dark:border-zinc-900 text-orange-600 shadow-sm hover:shadow-md active:scale-95"
          )}
        >
          <Bell size={24} className={isCallingWaiter ? "" : "animate-bounce"} />
          <span className="text-[10px] font-black uppercase tracking-widest">Call Waiter</span>
        </button>
        <button
          onClick={requestBill}
          className="flex flex-col items-center justify-center gap-3 p-6 rounded-[32px] bg-white dark:bg-zinc-900 border-2 border-white dark:border-zinc-900 text-gray-600 dark:text-zinc-400 shadow-sm hover:shadow-md active:scale-95 transition-all"
        >
          <CreditCard size={24} />
          <span className="text-[10px] font-black uppercase tracking-widest">Request Bill</span>
        </button>
      </div>

      {/* Order Summary */}
      <div className="mt-12 bg-white dark:bg-zinc-900 rounded-[40px] p-8 shadow-sm border border-gray-50 dark:border-zinc-800">
        <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 dark:text-zinc-500 mb-6">Order Details</h4>
        <div className="space-y-4">
          {order.items.map((item, idx) => (
            <div key={idx} className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 bg-gray-50 dark:bg-zinc-800 rounded-lg flex items-center justify-center text-[10px] font-black text-gray-400 dark:text-zinc-500">{item.quantity}x</span>
                <span className="text-sm font-bold text-gray-700 dark:text-zinc-300">{item.name}</span>
              </div>
              <span className="text-sm font-black text-gray-900 dark:text-white">{formatCurrency(item.price * item.quantity, lang)}</span>
            </div>
          ))}
          <div className="pt-6 mt-6 border-t border-gray-50 dark:border-zinc-800 flex justify-between items-center">
            <span className="text-gray-400 dark:text-zinc-500 font-bold">Total Amount</span>
            <span className="text-2xl font-black text-orange-600">{formatCurrency(order.totalPrice, lang)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
