import { useState, useEffect, useCallback } from "react";
import { ChefHat, Clock, CheckCircle2, AlertCircle, Play, Check, Mic } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import DashboardLayout from "../components/DashboardLayout";
import { Order, Table } from "../types";
import { cn } from "../lib/utils";
import { useLanguage, formatTime } from "../lib/i18n";
import { db } from "../firebase";
import { collection, doc, onSnapshot, updateDoc, addDoc, query, orderBy } from "firebase/firestore";
import { handleFirestoreError, OperationType } from "../firebase";

export default function KitchenDashboard() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [loading, setLoading] = useState(true);
  const { lang } = useLanguage();

  useEffect(() => {
    // Orders Listener
    const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));
    const unsubscribeOrders = onSnapshot(q, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({ 
        id: doc.id, 
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate?.()?.toISOString() || doc.data().createdAt
      } as Order));
      
      // Check for new orders to play sound
      const newOrders = ordersData.filter(o => o.status === "pending" && !orders.find(prev => prev.id === o.id));
      if (newOrders.length > 0) {
        const audio = new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");
        audio.play().catch(() => {});
        toast.info(`New order received!`, { icon: <AlertCircle className="text-orange-600" /> });
      }

      setOrders(ordersData);
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "orders"));

    // Tables Listener
    const unsubscribeTables = onSnapshot(collection(db, "tables"), (snapshot) => {
      const tablesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Table));
      setTables(tablesData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "tables"));

    return () => {
      unsubscribeOrders();
      unsubscribeTables();
    };
  }, [orders]);

  const updateStatus = async (orderId: string, status: Order["status"]) => {
    try {
      await updateDoc(doc(db, "orders", orderId), { status });
      
      if (status === "ready") {
        const order = orders.find(o => o.id === orderId);
        if (order) {
          await addDoc(collection(db, "notifications"), {
            type: "ORDER_READY",
            tableId: order.tableId,
            tableNumber: getTableNumber(order.tableId),
            message: `Order #${orderId.slice(-6).toUpperCase()} is ready for Table ${getTableNumber(order.tableId)}`,
            status: "unread",
            createdAt: new Date().toISOString()
          });
        }
      }
      toast.success(`Order status updated to ${status}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "orders");
    }
  };

  const activeOrders = orders.filter((o) => o.status === "pending" || o.status === "preparing");
  const readyOrders = orders.filter((o) => o.status === "ready");

  const getTableNumber = (tableId: string) => {
    return tables.find((t) => t.id === tableId)?.number || "??";
  };

  return (
    <DashboardLayout title="Kitchen Dashboard">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Active Orders */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-orange-100 dark:bg-orange-900/30 p-2 rounded-lg text-orange-600">
              <ChefHat size={20} />
            </div>
            <h3 className="text-xl font-bold dark:text-white">Active Orders</h3>
            <span className="bg-orange-600 text-white text-xs font-bold px-2 py-1 rounded-full">
              {activeOrders.length}
            </span>
          </div>

          <div className="space-y-4">
            <AnimatePresence mode="popLayout">
              {activeOrders.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white dark:bg-zinc-900 border dark:border-zinc-800 rounded-2xl p-12 text-center text-gray-400"
                >
                  <ChefHat size={48} className="mx-auto mb-4 opacity-20" />
                  <p className="font-medium">No active orders at the moment</p>
                </motion.div>
              ) : (
                activeOrders.map((order) => (
                  <motion.div
                    layout
                    key={order.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className={cn(
                      "bg-white dark:bg-zinc-900 border-2 rounded-2xl p-6 shadow-sm transition-all",
                      order.status === "preparing" 
                        ? "border-blue-200 dark:border-blue-900/50 bg-blue-50/30 dark:bg-blue-900/10" 
                        : "border-orange-200 dark:border-orange-900/50"
                    )}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="bg-gray-900 dark:bg-zinc-800 text-white w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg">
                          {getTableNumber(order.tableId)}
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 dark:text-zinc-400 font-bold uppercase tracking-wider">
                            Table Number
                          </p>
                          <p className="text-sm font-medium text-gray-400 dark:text-zinc-500">
                            #{order.id.slice(-6).toUpperCase()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-gray-500 dark:text-zinc-400 text-sm">
                        <Clock size={16} />
                        <span>{formatTime(order.createdAt, lang)}</span>
                      </div>
                    </div>

                    <div className="space-y-3 mb-6">
                      {order.items.map((item) => (
                        <div key={item.id} className="flex items-start justify-between group">
                          <div className="flex items-start gap-3">
                            <span className="bg-gray-100 dark:bg-zinc-800 text-gray-700 dark:text-zinc-300 font-bold px-2 py-0.5 rounded-md text-sm">
                              {item.quantity}x
                            </span>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-bold text-gray-900 dark:text-white">{item.name}</p>
                                {item.instructions && (
                                  <div className="bg-red-50 dark:bg-red-900/20 p-1 rounded-md text-red-600">
                                    <Mic size={14} />
                                  </div>
                                )}
                              </div>
                              {item.instructions && (
                                <p className="text-xs text-red-500 font-medium mt-0.5 italic">
                                  Note: {item.instructions}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex gap-3">
                      {order.status === "pending" ? (
                        <button
                          onClick={() => updateStatus(order.id, "preparing")}
                          className="flex-grow bg-blue-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
                        >
                          <Play size={18} />
                          Start Preparing
                        </button>
                      ) : (
                        <button
                          onClick={() => updateStatus(order.id, "ready")}
                          className="flex-grow bg-green-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-green-700 transition-colors"
                        >
                          <Check size={18} />
                          Mark as Ready
                        </button>
                      )}
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </section>

        {/* Ready Orders */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-lg text-green-600">
              <CheckCircle2 size={20} />
            </div>
            <h3 className="text-xl font-bold dark:text-white">Ready to Serve</h3>
            <span className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full">
              {readyOrders.length}
            </span>
          </div>

          <div className="space-y-4">
            <AnimatePresence mode="popLayout">
              {readyOrders.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white dark:bg-zinc-900 border dark:border-zinc-800 rounded-2xl p-12 text-center text-gray-400"
                >
                  <CheckCircle2 size={48} className="mx-auto mb-4 opacity-20" />
                  <p className="font-medium">No orders ready for pickup</p>
                </motion.div>
              ) : (
                readyOrders.map((order) => (
                  <motion.div
                    layout
                    key={order.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white dark:bg-zinc-900 border-2 border-green-100 dark:border-green-900/50 rounded-2xl p-6 shadow-sm"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-green-600 text-white w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg">
                          {getTableNumber(order.tableId)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900 dark:text-white">
                            Table {getTableNumber(order.tableId)}
                          </p>
                          <p className="text-xs text-green-600 font-bold uppercase">Ready</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500 dark:text-zinc-400">Order #{order.id.slice(-6).toUpperCase()}</p>
                        <p className="text-xs text-gray-400 dark:text-zinc-500">{order.items.length} items</p>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </section>
      </div>
    </DashboardLayout>
  );
}
