import React, { useState, useEffect } from "react";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { auth, db } from "../firebase";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";
import { LogIn, Lock, Loader2, Delete, ChevronRight } from "lucide-react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!email || !password) {
      toast.error("Please enter email and password");
      return;
    }

    setIsLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      toast.success("Access granted!");
      
      // Check role and navigate
      const user = auth.currentUser;
      if (user) {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        const userData = userDoc.data();
        
        if (userData?.role === "admin") navigate("/admin");
        else if (userData?.role === "kitchen") navigate("/kitchen");
        else if (userData?.role === "cashier") navigate("/cashier");
        else navigate("/admin");
      }
    } catch (error: any) {
      console.error("Auth error:", error);
      toast.error("Authentication failed. Please check your credentials.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 dark:bg-black p-4 transition-colors duration-300">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-8"
      >
        <div className="text-center space-y-2">
          <div className="w-20 h-20 bg-orange-600 rounded-[32px] flex items-center justify-center mx-auto mb-6 shadow-xl shadow-orange-200 dark:shadow-none">
            <Lock className="text-white" size={32} />
          </div>
          <h2 className="text-3xl font-black tracking-tight text-gray-900 dark:text-white">
            Staff Login
          </h2>
          <p className="text-sm text-gray-500 dark:text-zinc-400">
            Enter your credentials to continue
          </p>
        </div>

        <div className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-gray-900 dark:text-white"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-gray-900 dark:text-white"
          />
          <button
            onClick={handleLogin}
            disabled={isLoading}
            className="w-full p-4 rounded-xl bg-orange-600 text-white font-bold hover:bg-orange-700 transition-all flex items-center justify-center gap-2"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : <LogIn size={20} />}
            {isLoading ? "Logging in..." : "Login"}
          </button>
        </div>

        <div className="pt-8 text-center">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
            Authorized Personnel Only
          </p>
        </div>
      </motion.div>
    </div>
  );
}
