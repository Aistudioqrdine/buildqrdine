import { useState, useEffect, useMemo, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ShoppingCart, Plus, Minus, X, ChevronRight, Info, Bell, Mic, MicOff, Star, Flame, Leaf, Clock, Utensils, Moon, Sun } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { MenuItem, OrderItem, Table } from "../types";
import { cn } from "../lib/utils";
import { useLanguage, formatCurrency } from "../lib/i18n";
import { db } from "../firebase";
import { collection, doc, onSnapshot, addDoc, serverTimestamp, query, where, getDoc } from "firebase/firestore";

export default function CustomerMenu() {
  const { tableId } = useParams<{ tableId: string }>();
  const navigate = useNavigate();
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [table, setTable] = useState<Table | null>(null);
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [loading, setLoading] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [isCallingWaiter, setIsCallingWaiter] = useState(false);
  const { lang, setLang } = useLanguage();
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [isUpsellOpen, setIsUpsellOpen] = useState(false);
  const [phone, setPhone] = useState("");
  const [recommendations, setRecommendations] = useState<MenuItem[]>([]);
  const [isFirstVisit, setIsFirstVisit] = useState(true);
  const [userName, setUserName] = useState<string | null>(null);
  const [instructions, setInstructions] = useState("");
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem("theme") === "dark";
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDarkMode]);

  useEffect(() => {
    const handleStorageChange = () => {
      setIsDarkMode(localStorage.getItem("theme") === "dark");
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  const t = {
    en: {
      qrDine: "QR Dine",
      table: "Table",
      all: "All",
      yourOrder: "Your Order",
      emptyCart: "Your cart is empty",
      total: "Total",
      placeOrder: "Place Order",
      viewCart: "View Cart",
      items: "items",
      waiterNotified: "Waiter notified! Someone will be with you shortly.",
      failedWaiter: "Failed to notify waiter",
      listening: "Listening for instructions...",
      voiceCaptured: "Voice instruction captured!",
      addedToCart: "Added to cart",
      unavailable: "Item is currently unavailable",
      recommended: "Recommended for you",
      customersAlsoOrdered: "Customers also ordered",
      addToCart: "Add to Cart",
      loyalty: "Phone for Loyalty (Optional)",
      upsellTitle: "Complete your meal?",
      upsellDesc: "Customers who ordered this also enjoyed these items:",
      skip: "Skip & Order",
      mins: "mins",
      kcal: "kcal",
      welcomeBack: "Welcome back",
      reorderFavs: "Reorder your favorites",
      firstTimeOffer: "First time? Get 10% off your first order!",
      happyHour: "Happy Hour! All drinks 20% off until 6 PM.",
      specialInstructions: "Special Instructions",
      voiceNote: "Voice Note",
      instructionPlaceholder: "Any special requests? (e.g. no onions, extra spicy)",
    },
    ar: {
      qrDine: "كيو آر داين",
      table: "طاولة",
      all: "الكل",
      yourOrder: "طلبك",
      emptyCart: "سلة التسوق فارغة",
      total: "المجموع",
      placeOrder: "إتمام الطلب",
      viewCart: "عرض السلة",
      items: "أصناف",
      waiterNotified: "تم إخطار النادل! سيأتي إليك شخص ما قريبًا.",
      failedWaiter: "فشل في إخطار النادل",
      listening: "جاري الاستماع للتعليمات...",
      voiceCaptured: "تم التقاط التعليمات الصوتية!",
      addedToCart: "تمت الإضافة إلى السلة",
      unavailable: "الصنف غير متوفر حالياً",
      recommended: "مقترح لك",
      customersAlsoOrdered: "عملاء طلبوا أيضاً",
      addToCart: "إضافة للسلة",
      loyalty: "رقم الهاتف للولاء (اختياري)",
      upsellTitle: "أكمل وجبتك؟",
      upsellDesc: "العملاء الذين طلبوا هذا استمتعوا أيضاً بهذه الأصناف:",
      skip: "تخطي واطلب",
      mins: "دقيقة",
      kcal: "سعرة",
      welcomeBack: "مرحباً بعودتك",
      reorderFavs: "أعد طلب مفضلاتك",
      firstTimeOffer: "أول مرة؟ احصل على خصم 10٪ على طلبك الأول!",
      happyHour: "ساعة السعادة! خصم 20٪ على جميع المشروبات حتى 6 مساءً.",
      specialInstructions: "تعليمات خاصة",
      voiceNote: "ملاحظة صوتية",
      instructionPlaceholder: "أي طلبات خاصة؟ (مثلاً: بدون بصل، حار جداً)",
    },
  }[lang];

  useEffect(() => {
    const savedPhone = localStorage.getItem("qr_dine_phone");
    if (savedPhone) {
      setPhone(savedPhone);
      setIsFirstVisit(false);
      setUserName("Omar"); // Mocked name for demo
    }
  }, []);

  useEffect(() => {
    document.dir = lang === "ar" ? "rtl" : "ltr";
    return () => { document.dir = "ltr"; };
  }, [lang]);

  useEffect(() => {
    if (!tableId) return;

    // Fetch Table
    const unsubTable = onSnapshot(doc(db, "tables", tableId), (doc) => {
      if (doc.exists()) {
        setTable({ ...doc.data(), id: doc.id } as Table);
      } else {
        toast.error("Invalid table ID");
      }
    });

    // Fetch Menu
    const unsubMenu = onSnapshot(collection(db, "menu"), (snapshot) => {
      const menuData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as MenuItem));
      setMenu(menuData);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching menu:", error);
      toast.error("Failed to load menu");
      setLoading(false);
    });

    return () => {
      unsubTable();
      unsubMenu();
    };
  }, [tableId]);

  useEffect(() => {
    if (selectedItem) {
      // Recommendations logic could be moved to Firestore too, but for now we can filter from local menu
      const recs = menu.filter(m => m.category.en === selectedItem.category.en && m.id !== selectedItem.id).slice(0, 3);
      setRecommendations(recs);
    }
  }, [selectedItem, menu]);

  const callWaiter = async () => {
    if (isCallingWaiter || !table) return;
    setIsCallingWaiter(true);
    try {
      await addDoc(collection(db, "notifications"), {
        type: "WAITER_CALL",
        tableId,
        tableNumber: table.number,
        message: `Table ${table.number} is calling for a waiter`,
        status: "unread",
        createdAt: serverTimestamp(),
      });
      toast.success(t.waiterNotified);
    } catch (error) {
      console.error("Error notifying waiter:", error);
      toast.error(t.failedWaiter);
    } finally {
      setTimeout(() => setIsCallingWaiter(false), 30000);
    }
  };

  const toggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true);
      toast.info(t.listening);
      setTimeout(() => {
        setIsRecording(false);
        toast.success(t.voiceCaptured);
      }, 3000);
    } else {
      setIsRecording(false);
    }
  };

  const categories = useMemo(() => {
    const cats = Array.from(new Set(menu.map((item) => item.category[lang])));
    return [t.all, ...cats];
  }, [menu, lang, t.all]);

  const filteredMenu = useMemo(() => {
    if (activeCategory === t.all) return menu;
    return menu.filter((item) => item.category[lang] === activeCategory);
  }, [menu, activeCategory, lang, t.all]);

  useEffect(() => {
    if (menu.length > 0) {
      setCart(prev => prev.map(item => {
        const menuItem = menu.find(m => m.id === item.menuItemId);
        if (menuItem) {
          return { ...item, name: menuItem.name[lang] };
        }
        return item;
      }));
    }
  }, [lang, menu]);

  const addToCart = (item: MenuItem) => {
    if (!item.available) {
      toast.error(t.unavailable);
      return;
    }
    setCart((prev) => {
      const existing = prev.find((i) => i.menuItemId === item.id);
      if (existing) {
        return prev.map((i) =>
          i.menuItemId === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [
        ...prev,
        {
          id: Math.random().toString(36).substr(2, 9),
          menuItemId: item.id,
          name: item.name[lang],
          quantity: 1,
          price: item.price,
          instructions: instructions,
        },
      ];
    });
    setInstructions("");
    toast.success(`${t.addedToCart}: ${item.name[lang]}`);
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((i) => i.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev.map((i) => {
        if (i.id === id) {
          const newQty = Math.max(1, i.quantity + delta);
          return { ...i, quantity: newQty };
        }
        return i;
      })
    );
  };

  const cartTotal = useMemo(() => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  }, [cart]);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    // Simple upsell logic: if no drinks, show upsell
    const hasDrink = cart.some(item => {
      const menuItem = menu.find(m => m.id === item.menuItemId);
      return menuItem?.category.en === "Drinks";
    });
    if (!hasDrink) {
      setIsUpsellOpen(true);
    } else {
      placeOrder();
    }
  };

  const placeOrder = async () => {
    try {
      if (phone) {
        localStorage.setItem("qr_dine_phone", phone);
      }
      
      const orderData = {
        tableId,
        tableNumber: table?.number || 0,
        items: cart,
        totalPrice: cartTotal,
        status: "pending",
        customerPhone: phone,
        createdAt: serverTimestamp(),
      };

      const docRef = await addDoc(collection(db, "orders"), orderData);
      
      toast.success(lang === "en" ? "Order placed successfully!" : "تم تقديم الطلب بنجاح!");
      navigate(`/order/${docRef.id}`);
    } catch (error) {
      console.error("Error placing order:", error);
      toast.error(lang === "en" ? "Failed to place order" : "فشل في تقديم الطلب");
    }
  };

  const renderTag = (tag: string) => {
    switch (tag) {
      case "spicy": return <Flame size={12} className="text-red-500" />;
      case "vegan": return <Leaf size={12} className="text-green-500" />;
      case "bestseller": return <Star size={12} className="text-yellow-500" />;
      case "chef-choice": return <Utensils size={12} className="text-purple-500" />;
      default: return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50 dark:bg-gray-900">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
          className="rounded-full h-12 w-12 border-4 border-orange-500 border-t-transparent"
        />
      </div>
    );
  }

  return (
    <div className="max-w-md md:max-w-3xl lg:max-w-5xl mx-auto bg-gray-50 dark:bg-gray-900 min-h-screen pb-24 relative font-sans transition-colors duration-300" dir={lang === "ar" ? "rtl" : "ltr"}>
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-100 dark:border-gray-800 px-6 py-4 flex items-center justify-between shadow-sm transition-colors duration-300">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-orange-200 dark:shadow-none">
            Q
          </div>
          <div>
            <h1 className="text-xl font-black text-gray-900 dark:text-white tracking-tight">{t.qrDine}</h1>
            <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest">{t.table} {table?.number}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2.5 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all active:scale-95"
          >
            {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button
            onClick={() => setLang(lang === "en" ? "ar" : "en")}
            className="px-3 py-1.5 bg-gray-100 dark:bg-gray-800 rounded-full text-[10px] font-black uppercase tracking-wider hover:bg-gray-200 dark:hover:bg-gray-700 dark:text-gray-300 transition-all active:scale-95"
          >
            {lang === "en" ? "العربية" : "English"}
          </button>
          <button
            onClick={callWaiter}
            disabled={isCallingWaiter}
            className={cn(
              "p-2.5 rounded-full transition-all shadow-sm",
              isCallingWaiter ? "bg-gray-100 dark:bg-gray-800 text-gray-400 dark:text-gray-500" : "bg-orange-50 dark:bg-orange-900/30 text-orange-600 hover:bg-orange-100 dark:hover:bg-orange-900/50 active:scale-90"
            )}
          >
            <Bell size={20} className={isCallingWaiter ? "" : "animate-pulse"} />
          </button>
        </div>
      </header>

      {/* Voice Instruction Floating Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={toggleRecording}
        className={cn(
          "fixed z-30 w-16 h-16 rounded-full flex items-center justify-center shadow-2xl transition-all",
          lang === "en" ? "right-6" : "left-6",
          "bottom-28",
          isRecording ? "bg-red-500 text-white animate-pulse" : "bg-white dark:bg-gray-800 text-orange-600 border-4 border-orange-50 dark:border-gray-700"
        )}
      >
        {isRecording ? <MicOff size={28} /> : <Mic size={28} />}
      </motion.button>

      {/* Hero / Featured */}
      <div className="px-6 pt-6 space-y-6">
        {userName && (
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 mb-2"
          >
            <span className="text-2xl font-black text-gray-900 dark:text-white">{t.welcomeBack}, {userName}! 👋</span>
          </motion.div>
        )}

        <div className="grid grid-cols-1 gap-4">
          {isFirstVisit ? (
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-[32px] p-5 text-white flex items-center gap-4 shadow-xl shadow-indigo-200 dark:shadow-none"
            >
              <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-md">
                <Star size={24} className="text-yellow-300 fill-yellow-300" />
              </div>
              <div>
                <p className="text-sm font-black leading-tight">{t.firstTimeOffer}</p>
                <p className="text-[10px] font-bold opacity-70 mt-1 uppercase tracking-wider">Limited Time Only</p>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-[32px] p-5 text-white flex items-center gap-4 shadow-xl shadow-purple-200 dark:shadow-none"
            >
              <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-md">
                <Clock size={24} className="text-purple-200" />
              </div>
              <div>
                <p className="text-sm font-black leading-tight">{t.happyHour}</p>
                <p className="text-[10px] font-bold opacity-70 mt-1 uppercase tracking-wider">Valid until 6:00 PM</p>
              </div>
            </motion.div>
          )}

          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-[40px] p-8 text-white relative overflow-hidden shadow-2xl shadow-orange-200 dark:shadow-none"
          >
            <div className="relative z-10">
              <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider backdrop-blur-md">Featured</span>
              <h2 className="text-3xl font-black mt-3 leading-tight">Chef's Special<br/>Selection</h2>
              <p className="text-xs font-bold opacity-80 mt-2 max-w-[200px]">Hand-picked ingredients for an unforgettable taste.</p>
              <button className="mt-6 bg-white text-orange-600 px-6 py-3 rounded-2xl text-xs font-black shadow-xl active:scale-95 transition-all">Order Now</button>
            </div>
            <div className="absolute -right-10 -bottom-10 w-56 h-56 bg-white/10 rounded-full blur-3xl" />
            <Utensils className="absolute -right-4 -bottom-4 text-white/10 rotate-12" size={180} />
          </motion.div>
        </div>
      </div>

      {/* Favorites / Reorder */}
      {!isFirstVisit && menu.length > 0 && (
        <div className="px-6 pt-8">
          <h3 className="text-xs font-black uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-4">{t.reorderFavs}</h3>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            {menu.slice(0, 3).map(item => (
              <motion.div 
                key={item.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => addToCart(item)}
                className="w-40 flex-shrink-0 bg-white dark:bg-gray-800 p-3 rounded-3xl border border-gray-50 dark:border-gray-700 shadow-sm"
              >
                <div className="w-full h-24 rounded-2xl overflow-hidden mb-2">
                  <img src={item.image} className="w-full h-full object-cover" alt="" referrerPolicy="no-referrer" />
                </div>
                <p className="text-[10px] font-bold text-gray-900 dark:text-white truncate">{item.name[lang]}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[10px] font-black text-orange-600">{formatCurrency(item.price, lang)}</span>
                  <Plus size={14} className="text-orange-600" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Categories */}
      <div className="px-6 py-6 overflow-x-auto flex gap-3 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={cn(
              "px-5 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all shadow-sm",
              activeCategory === cat
                ? "bg-orange-600 text-white shadow-orange-200 dark:shadow-none scale-105"
                : "bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700"
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Menu Items */}
      <div className="px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMenu.map((item) => (
          <motion.div
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            key={item.id}
            className="bg-white dark:bg-zinc-900 rounded-[40px] p-5 flex gap-5 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group cursor-pointer border border-gray-50 dark:border-zinc-800"
            onClick={() => setSelectedItem(item)}
          >
            <div className="w-32 h-32 rounded-[32px] overflow-hidden flex-shrink-0 bg-gray-50 dark:bg-zinc-800 relative shadow-inner">
              <img
                src={item.image}
                alt={item.name[lang]}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              {item.tags && item.tags.length > 0 && (
                <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                  {item.tags.map(tag => (
                    <div key={tag} className="bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md p-1.5 rounded-xl shadow-lg border border-white/20">
                      {renderTag(tag)}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="flex-grow flex flex-col justify-between py-1">
              <div>
                <div className="flex justify-between items-start">
                  <h3 className="font-black text-gray-900 dark:text-white text-xl leading-tight group-hover:text-orange-600 transition-colors">{item.name[lang]}</h3>
                </div>
                <p className="text-[11px] text-gray-400 dark:text-zinc-500 font-bold line-clamp-2 mt-2 leading-relaxed">
                  {item.description[lang]}
                </p>
              </div>
              <div className="flex items-end justify-between mt-3">
                <div className="flex flex-col">
                  <span className="text-[9px] text-gray-400 dark:text-zinc-500 font-black uppercase tracking-widest">Price</span>
                  <span className="font-black text-orange-600 text-2xl tracking-tight">{formatCurrency(item.price, lang)}</span>
                </div>
                <button 
                  onClick={(e) => { e.stopPropagation(); addToCart(item); }}
                  className="w-12 h-12 bg-orange-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-orange-200 dark:shadow-none active:scale-90 transition-all hover:bg-orange-700"
                >
                  <Plus size={24} strokeWidth={3} />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Item Detail Modal */}
      <AnimatePresence>
        {selectedItem && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedItem(null)}
              className="fixed inset-0 bg-black/60 z-[60] backdrop-blur-md"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 max-w-md md:max-w-3xl lg:max-w-5xl mx-auto bg-white dark:bg-gray-900 rounded-t-[48px] z-[70] overflow-hidden shadow-2xl"
            >
              <div className="h-72 relative">
                <img 
                  src={selectedItem.image} 
                  className="w-full h-full object-cover" 
                  alt={selectedItem.name[lang]} 
                  referrerPolicy="no-referrer"
                />
                <button 
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-6 right-6 w-10 h-10 bg-black/20 dark:bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-black/30 transition-colors"
                >
                  <X size={20} />
                </button>
                <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-white dark:from-gray-900 to-transparent" />
              </div>
              
              <div className="px-8 pb-10 -mt-6 relative z-10">
                <div className="flex justify-between items-center">
                  <h2 className="text-3xl font-black text-gray-900 dark:text-white">{selectedItem.name[lang]}</h2>
                  <span className="text-2xl font-black text-orange-600">{formatCurrency(selectedItem.price, lang)}</span>
                </div>
                
                <div className="flex gap-4 mt-4">
                  {selectedItem.prepTime && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider bg-gray-50 dark:bg-gray-800 px-3 py-1.5 rounded-xl">
                      <Clock size={14} className="text-orange-500" />
                      {selectedItem.prepTime} {t.mins}
                    </div>
                  )}
                  {selectedItem.calories && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider bg-gray-50 dark:bg-gray-800 px-3 py-1.5 rounded-xl">
                      <Flame size={14} className="text-red-500" />
                      {selectedItem.calories} {t.kcal}
                    </div>
                  )}
                </div>

                <p className="mt-6 text-gray-500 dark:text-gray-400 text-sm leading-relaxed font-medium">
                  {selectedItem.description[lang]}
                </p>

                {/* Special Instructions */}
                <div className="mt-8 space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 dark:text-gray-500">{t.specialInstructions}</label>
                    <button 
                      onClick={() => {
                        toast.info(t.listening);
                        setTimeout(() => {
                          setInstructions("Extra spicy, please!");
                          toast.success(t.voiceCaptured);
                        }, 2000);
                      }}
                      className="flex items-center gap-2 text-orange-600 font-bold text-xs hover:bg-orange-50 dark:hover:bg-orange-900/30 px-3 py-1.5 rounded-xl transition-colors"
                    >
                      <Mic size={14} />
                      {t.voiceNote}
                    </button>
                  </div>
                  <textarea
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    placeholder={t.instructionPlaceholder}
                    className="w-full bg-gray-50 dark:bg-gray-800 border-none rounded-2xl p-5 text-sm font-medium text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500/20 transition-all resize-none placeholder:text-gray-400 dark:placeholder:text-gray-500"
                    rows={3}
                  />
                </div>

                {recommendations.length > 0 && (
                  <div className="mt-8">
                    <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-4">{t.customersAlsoOrdered}</h4>
                    <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                      {recommendations.map(rec => (
                        <div 
                          key={rec.id} 
                          className="w-32 flex-shrink-0 cursor-pointer"
                          onClick={() => setSelectedItem(rec)}
                        >
                          <div className="w-32 h-24 rounded-2xl overflow-hidden bg-gray-100 dark:bg-gray-800 mb-2">
                            <img src={rec.image} className="w-full h-full object-cover" alt={rec.name[lang]} referrerPolicy="no-referrer" />
                          </div>
                          <p className="text-[10px] font-bold text-gray-900 dark:text-white truncate">{rec.name[lang]}</p>
                          <p className="text-[10px] font-black text-orange-600">{formatCurrency(rec.price, lang)}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <button
                  onClick={() => { addToCart(selectedItem); setSelectedItem(null); }}
                  className="w-full mt-8 bg-orange-600 text-white py-5 rounded-[24px] font-black text-lg shadow-xl shadow-orange-100 dark:shadow-none active:scale-95 transition-all"
                >
                  {t.addToCart}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Cart Drawer */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/40 z-[80] backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: lang === "en" ? "100%" : "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: lang === "en" ? "100%" : "-100%" }}
              className={cn(
                "fixed inset-y-0 w-full max-w-md bg-white dark:bg-gray-900 z-[90] shadow-2xl flex flex-col",
                lang === "en" ? "right-0" : "left-0"
              )}
            >
              <div className="p-8 border-b border-gray-50 dark:border-gray-800 flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-black text-gray-900 dark:text-white">{t.yourOrder}</h2>
                  <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-1">{cart.length} {t.items}</p>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="w-12 h-12 bg-gray-50 dark:bg-gray-800 rounded-2xl flex items-center justify-center text-gray-400 dark:text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-grow overflow-y-auto p-8 space-y-6 no-scrollbar">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center">
                    <div className="w-24 h-24 bg-orange-50 dark:bg-orange-900/30 rounded-[40px] flex items-center justify-center text-orange-600 mb-6">
                      <ShoppingCart size={48} />
                    </div>
                    <p className="text-gray-400 dark:text-gray-500 font-bold">{t.emptyCart}</p>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div key={item.id} className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-2xl bg-gray-50 dark:bg-gray-800 overflow-hidden flex-shrink-0">
                        <img 
                          src={menu.find(m => m.id === item.menuItemId)?.image} 
                          className="w-full h-full object-cover" 
                          alt={item.name} 
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="flex-grow">
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">{item.name}</h4>
                        <p className="text-xs font-black text-orange-600 mt-1">
                          {formatCurrency(item.price * item.quantity, lang)}
                        </p>
                      </div>
                      <div className="flex items-center gap-3 bg-gray-50 dark:bg-gray-800 rounded-xl p-1.5">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="w-6 h-6 bg-white dark:bg-gray-700 rounded-lg flex items-center justify-center text-gray-400 dark:text-gray-300 shadow-sm"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="text-xs font-black w-4 text-center dark:text-white">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="w-6 h-6 bg-white dark:bg-gray-700 rounded-lg flex items-center justify-center text-gray-400 dark:text-gray-300 shadow-sm"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-8 bg-gray-50/50 dark:bg-gray-800/50 border-t border-gray-100 dark:border-gray-800 space-y-6">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-2 block">{t.loyalty}</label>
                    <input 
                      type="tel" 
                      placeholder="05x xxxx xxx"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-700 rounded-2xl px-5 py-4 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all placeholder:text-gray-400 dark:placeholder:text-gray-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 dark:text-gray-500 font-bold">{t.total}</span>
                    <span className="text-3xl font-black text-gray-900 dark:text-white">{formatCurrency(cartTotal, lang)}</span>
                  </div>
                  <button
                    onClick={handleCheckout}
                    className="w-full bg-orange-600 text-white py-5 rounded-[24px] font-black text-lg shadow-xl shadow-orange-200 dark:shadow-none active:scale-[0.98] transition-all"
                  >
                    {t.placeOrder}
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Upsell Modal */}
      <AnimatePresence>
        {isUpsellOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 z-[100] backdrop-blur-xl"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="fixed inset-0 m-auto w-[90%] max-w-sm h-fit bg-white dark:bg-gray-900 rounded-[40px] z-[110] p-8 shadow-2xl"
            >
              <h3 className="text-2xl font-black text-gray-900 dark:text-white text-center">{t.upsellTitle}</h3>
              <p className="text-gray-400 dark:text-gray-500 text-center text-xs font-medium mt-2">{t.upsellDesc}</p>
              
              <div className="mt-8 space-y-4">
                {menu.filter(m => m.category.en === "Drinks" || m.category.en === "Starters").slice(0, 2).map(item => (
                  <div key={item.id} className="flex items-center gap-4 bg-gray-50 dark:bg-gray-800 p-3 rounded-3xl">
                    <img src={item.image} className="w-16 h-16 rounded-2xl object-cover" alt="" referrerPolicy="no-referrer" />
                    <div className="flex-grow">
                      <h4 className="font-bold text-sm text-gray-900 dark:text-white">{item.name[lang]}</h4>
                      <p className="text-orange-600 font-black text-xs">{formatCurrency(item.price, lang)}</p>
                    </div>
                    <button 
                      onClick={() => { addToCart(item); setIsUpsellOpen(false); placeOrder(); }}
                      className="bg-white dark:bg-gray-700 p-2 rounded-xl shadow-sm text-orange-600"
                    >
                      <Plus size={20} />
                    </button>
                  </div>
                ))}
              </div>

              <div className="mt-8 space-y-3">
                <button
                  onClick={() => { setIsUpsellOpen(false); placeOrder(); }}
                  className="w-full bg-orange-600 text-white py-4 rounded-2xl font-black shadow-lg shadow-orange-100 dark:shadow-none"
                >
                  {t.placeOrder}
                </button>
                <button
                  onClick={() => { setIsUpsellOpen(false); placeOrder(); }}
                  className="w-full text-gray-400 dark:text-gray-500 py-2 text-xs font-bold hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                >
                  {t.skip}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Floating Cart Bar */}
      {cart.length > 0 && !isCartOpen && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-8 left-6 right-6 max-w-md mx-auto z-30"
        >
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full bg-orange-600 text-white p-5 rounded-[28px] flex items-center justify-between shadow-2xl shadow-orange-200 dark:shadow-none active:scale-95 transition-all"
          >
            <div className="flex items-center gap-4">
              <div className="bg-white/20 p-2.5 rounded-2xl">
                <ShoppingCart size={22} />
              </div>
              <div className="text-left">
                <p className="text-[10px] text-white/70 font-black uppercase tracking-widest">
                  {cart.reduce((sum, i) => sum + i.quantity, 0)} {t.items}
                </p>
                <p className="font-black text-lg leading-none">{t.viewCart}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-black text-2xl">{formatCurrency(cartTotal, lang)}</span>
              <div className="bg-white/20 p-1 rounded-lg">
                <ChevronRight size={20} className={lang === "ar" ? "rotate-180" : ""} />
              </div>
            </div>
          </button>
        </motion.div>
      )}
    </div>
  );
}
