import { useState, useEffect, useCallback, useMemo } from "react";
import { CreditCard, DollarSign, Receipt, CheckCircle2, ChevronRight, X, Printer, Bell } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import DashboardLayout from "../components/DashboardLayout";
import { Order, Table } from "../types";
import { cn } from "../lib/utils";
import { useLanguage, formatCurrency, formatTime } from "../lib/i18n";
import { db } from "../firebase";
import { collection, doc, onSnapshot, updateDoc, query, orderBy, where } from "firebase/firestore";
import { handleFirestoreError, OperationType } from "../firebase";

export default function CashierDashboard() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [isPrinting, setIsPrinting] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card">("card");
  const { lang } = useLanguage();

  const [isShiftSummaryOpen, setIsShiftSummaryOpen] = useState(false);

  useEffect(() => {
    // Orders Listener
    const unsubscribeOrders = onSnapshot(collection(db, "orders"), (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({ 
        id: doc.id, 
        ...doc.data(),
        total: doc.data().totalPrice,
        createdAt: doc.data().createdAt?.toDate?.()?.toISOString() || doc.data().createdAt
      } as Order));
      setOrders(ordersData);
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "orders"));

    // Tables Listener
    const unsubscribeTables = onSnapshot(collection(db, "tables"), (snapshot) => {
      const tablesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Table));
      setTables(tablesData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "tables"));

    // Notifications Listener
    const qNotif = query(collection(db, "notifications"), where("status", "==", "unread"), orderBy("createdAt", "desc"));
    const unsubscribeNotif = onSnapshot(qNotif, (snapshot) => {
      const notifData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      
      // Check for new bill requests
      const newBillRequests = notifData.filter(n => n.type === "BILL_REQUEST" && !notifications.find(prev => prev.id === n.id));
      if (newBillRequests.length > 0) {
        toast.info(`Bill request from Table ${newBillRequests[0].tableNumber}!`, { icon: <Receipt className="text-orange-600" /> });
        new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3").play().catch(() => {});
      }

      setNotifications(notifData);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "notifications"));

    return () => {
      unsubscribeOrders();
      unsubscribeTables();
      unsubscribeNotif();
    };
  }, [notifications]);

  const markAsPaid = async (orderId: string) => {
    try {
      const order = orders.find(o => o.id === orderId);
      if (!order) return;

      // 1. Mark order as paid
      await updateDoc(doc(db, "orders", orderId), { status: "paid" });

      // 2. Clear table status
      await updateDoc(doc(db, "tables", order.tableId), { status: "idle" });

      // 3. Clear any bill request notifications for this table
      const tableNotifs = notifications.filter(n => n.tableId === order.tableId && n.type === "BILL_REQUEST" && n.status === "unread");
      for (const notif of tableNotifs) {
        await updateDoc(doc(db, "notifications", notif.id), { status: "read" });
      }

      toast.success("Order marked as paid and table cleared");
      setSelectedOrder(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "orders");
    }
  };

  const simulatePrint = () => {
    setIsPrinting(true);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
    }, 500);
  };

  const billRequests = notifications.filter(n => n.type === "BILL_REQUEST" && n.status === "unread");
  const pendingPaymentOrders = orders.filter((o) => o.status === "ready");
  const completedOrders = orders.filter((o) => o.status === "paid");

  const getTableNumber = (tableId: string) => {
    return tables.find((t) => t.id === tableId)?.number || "??";
  };

  const shiftStats = useMemo(() => {
    const totalRevenue = completedOrders.reduce((acc, o) => acc + o.total, 0);
    const cashPayments = completedOrders.length * 0.4; // Simulated
    const cardPayments = completedOrders.length * 0.6; // Simulated
    return {
      total: totalRevenue,
      orders: completedOrders.length,
      cash: Math.floor(cashPayments),
      card: Math.floor(cardPayments)
    };
  }, [completedOrders]);

  return (
    <DashboardLayout title="Cashier Dashboard">
      <div className="flex justify-end mb-6">
        <button 
          onClick={() => setIsShiftSummaryOpen(true)}
          className="bg-gray-900 dark:bg-zinc-800 text-white px-6 py-2.5 rounded-2xl font-bold text-sm flex items-center gap-2 hover:bg-gray-800 dark:hover:bg-zinc-700 transition-all shadow-lg shadow-gray-200 dark:shadow-none"
        >
          <DollarSign size={18} />
          Shift Summary
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Orders List */}
        <div className="lg:col-span-2 space-y-8">
          {/* Bill Request Alerts */}
          {billRequests.length > 0 && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              className="space-y-3"
            >
              <h3 className="text-sm font-black uppercase tracking-widest text-orange-600 flex items-center gap-2">
                <Bell size={14} className="animate-bounce" />
                Bill Requests
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {billRequests.map((notif) => (
                  <motion.div
                    key={notif.id}
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="bg-orange-50 dark:bg-orange-900/20 border-2 border-orange-200 dark:border-orange-900/50 rounded-2xl p-4 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="bg-orange-600 text-white w-10 h-10 rounded-xl flex items-center justify-center font-bold">
                        {notif.tableNumber}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-orange-900 dark:text-orange-100">Table {notif.tableNumber}</p>
                        <p className="text-[10px] text-orange-600 font-medium">Requested {formatTime(notif.createdAt, lang)}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        const order = orders.find(o => o.tableId === notif.tableId && o.status === "ready");
                        if (order) setSelectedOrder(order);
                      }}
                      className="bg-orange-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-orange-700 transition-colors"
                    >
                      View Bill
                    </button>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-orange-100 dark:bg-orange-900/30 p-2 rounded-lg text-orange-600">
                <Receipt size={20} />
              </div>
              <h3 className="text-xl font-bold dark:text-white">Pending Payment</h3>
              <span className="bg-orange-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                {pendingPaymentOrders.length}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingPaymentOrders.length === 0 ? (
                <div className="col-span-2 bg-white dark:bg-zinc-900 border dark:border-zinc-800 rounded-2xl p-12 text-center text-gray-400">
                  <Receipt size={48} className="mx-auto mb-4 opacity-20" />
                  <p className="font-medium">No orders waiting for payment</p>
                </div>
              ) : (
                pendingPaymentOrders.map((order) => (
                  <motion.div
                    layout
                    key={order.id}
                    onClick={() => setSelectedOrder(order)}
                    className={cn(
                      "bg-white dark:bg-zinc-900 border-2 rounded-2xl p-6 cursor-pointer transition-all hover:border-orange-400 hover:shadow-md",
                      selectedOrder?.id === order.id ? "border-orange-600 shadow-lg" : "border-gray-100 dark:border-zinc-800"
                    )}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="bg-gray-900 dark:bg-zinc-800 text-white w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg">
                          {getTableNumber(order.tableId)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900 dark:text-white">Table {getTableNumber(order.tableId)}</p>
                          <p className="text-xs text-gray-500 dark:text-zinc-400">#{order.id.slice(-6).toUpperCase()}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-orange-600">{formatCurrency(order.total, lang)}</p>
                        <p className="text-xs text-gray-400 dark:text-zinc-500">{order.items.length} items</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-500 dark:text-zinc-400 pt-4 border-t dark:border-zinc-800">
                      <span>{formatTime(order.createdAt, lang)}</span>
                      <div className="flex items-center gap-1 text-orange-600 font-bold">
                        View Bill <ChevronRight size={16} />
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </section>

          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-lg text-green-600">
                <CheckCircle2 size={20} />
              </div>
              <h3 className="text-xl font-bold dark:text-white">Recent Payments</h3>
            </div>
            <div className="bg-white dark:bg-zinc-900 border dark:border-zinc-800 rounded-2xl overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-gray-50 dark:bg-zinc-800 border-b dark:border-zinc-700">
                  <tr>
                    <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Table</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Order ID</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Amount</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Time</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y dark:divide-zinc-800">
                  {completedOrders.slice(0, 5).map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors">
                      <td className="px-6 py-4 font-bold dark:text-white">Table {getTableNumber(order.tableId)}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-zinc-400">#{order.id.slice(-6).toUpperCase()}</td>
                      <td className="px-6 py-4 font-bold text-green-600">{formatCurrency(order.total, lang)}</td>
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-zinc-400">
                        {formatTime(order.createdAt, lang)}
                      </td>
                      <td className="px-6 py-4">
                        <span className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-[10px] font-bold px-2 py-1 rounded-md uppercase">Paid</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        {/* Bill Preview */}
        <div className="lg:col-span-1">
          <AnimatePresence mode="wait">
            {selectedOrder ? (
              <>
                {/* Mobile Overlay */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setSelectedOrder(null)}
                  className="fixed inset-0 bg-black/40 z-40 lg:hidden backdrop-blur-sm"
                />
                <motion.div
                  key={selectedOrder.id}
                  initial={{ opacity: 0, y: 100 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 100 }}
                  className="fixed inset-x-0 bottom-0 z-50 bg-white dark:bg-zinc-900 rounded-t-3xl p-6 shadow-2xl max-h-[90vh] overflow-y-auto lg:static lg:rounded-3xl lg:border-2 lg:border-orange-600 lg:p-8 lg:shadow-xl lg:sticky lg:top-8 print-area"
                >
                  <div className="flex items-center justify-between mb-6 lg:mb-8">
                    <h3 className="text-xl font-bold dark:text-white">Bill Summary</h3>
                    <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full no-print dark:text-white">
                      <X size={20} />
                    </button>
                  </div>

                  <div className="text-center mb-6 lg:mb-8 pb-6 lg:pb-8 border-b border-dashed dark:border-zinc-700">
                    <div className="bg-gray-900 dark:bg-zinc-800 text-white w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-2xl mx-auto mb-2">
                      {getTableNumber(selectedOrder.tableId)}
                    </div>
                    <p className="text-sm font-bold text-gray-900 dark:text-white uppercase tracking-widest">Table Number</p>
                    <p className="text-xs text-gray-400 dark:text-zinc-500 mt-1">Order #{selectedOrder.id.slice(-6).toUpperCase()}</p>
                  </div>

                <div className="space-y-4 mb-8">
                  {selectedOrder.items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <div className="flex gap-2">
                        <span className="font-bold text-gray-400 dark:text-zinc-500">{item.quantity}x</span>
                        <span className="text-gray-700 dark:text-zinc-300">{item.name}</span>
                      </div>
                      <span className="font-medium dark:text-white">{formatCurrency(item.price * item.quantity, lang)}</span>
                    </div>
                  ))}
                </div>

                <div className="space-y-3 pt-6 border-t dark:border-zinc-800">
                  <div className="flex justify-between text-sm text-gray-500 dark:text-zinc-400">
                    <span>Subtotal</span>
                    <span>{formatCurrency(selectedOrder.total, lang)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-500 dark:text-zinc-400">
                    <span>Tax (0%)</span>
                    <span>{formatCurrency(0, lang)}</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-gray-900 dark:text-white pt-2">
                    <span>Total</span>
                    <span>{formatCurrency(selectedOrder.total, lang)}</span>
                  </div>
                </div>

                <div className="mt-10 space-y-6 no-print">
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => setPaymentMethod("card")}
                      className={cn(
                        "flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all",
                        paymentMethod === "card" ? "border-orange-600 bg-orange-50 dark:bg-orange-900/20 text-orange-600" : "border-gray-100 dark:border-zinc-800 text-gray-400 dark:text-zinc-500"
                      )}
                    >
                      <CreditCard size={20} />
                      <span className="text-[10px] font-black uppercase tracking-widest">Card</span>
                    </button>
                    <button 
                      onClick={() => setPaymentMethod("cash")}
                      className={cn(
                        "flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all",
                        paymentMethod === "cash" ? "border-orange-600 bg-orange-50 dark:bg-orange-900/20 text-orange-600" : "border-gray-100 dark:border-zinc-800 text-gray-400 dark:text-zinc-500"
                      )}
                    >
                      <DollarSign size={20} />
                      <span className="text-[10px] font-black uppercase tracking-widest">Cash</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    <button
                      onClick={() => markAsPaid(selectedOrder.id)}
                      className="w-full bg-orange-600 text-white py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-orange-700 transition-all shadow-lg shadow-orange-100 dark:shadow-none"
                    >
                      <CheckCircle2 size={20} />
                      Complete Payment
                    </button>
                    <button 
                      onClick={simulatePrint}
                      disabled={isPrinting}
                      className="w-full bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-zinc-400 py-3 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-200 dark:hover:bg-zinc-700 transition-all disabled:opacity-50"
                    >
                      <Printer size={18} className={isPrinting ? "animate-spin" : ""} />
                      {isPrinting ? "Printing..." : "Print Receipt"}
                    </button>
                  </div>
                </div>
                </motion.div>
              </>
            ) : (
              <div className="bg-gray-100 dark:bg-zinc-900 border-2 border-dashed border-gray-200 dark:border-zinc-800 rounded-3xl p-12 text-center text-gray-400 h-[600px] flex flex-col items-center justify-center hidden lg:flex">
                <Receipt size={48} className="mb-4 opacity-20" />
                <p className="font-medium">Select an order to view the bill</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Shift Summary Modal */}
      <AnimatePresence>
        {isShiftSummaryOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsShiftSummaryOpen(false)}
              className="fixed inset-0 bg-black/60 z-[60] backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed inset-0 m-auto w-full max-w-sm h-fit bg-white dark:bg-zinc-900 rounded-[40px] z-[70] p-8 shadow-2xl border dark:border-zinc-800"
            >
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-[32px] flex items-center justify-center mx-auto mb-4">
                  <DollarSign size={40} />
                </div>
                <h3 className="text-2xl font-black text-gray-900 dark:text-white">Shift Summary</h3>
                <p className="text-sm text-gray-500 dark:text-zinc-400">Daily Balance Report</p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl col-span-2">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1 text-center">Total Revenue</p>
                  <p className="text-3xl font-black text-gray-900 dark:text-white text-center">{formatCurrency(shiftStats.total, lang)}</p>
                </div>
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Total Orders</p>
                  <p className="text-xl font-black text-gray-900 dark:text-white">{shiftStats.orders}</p>
                </div>
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Avg Order</p>
                  <p className="text-xl font-black text-gray-900 dark:text-white">{formatCurrency(shiftStats.total / (shiftStats.orders || 1), lang)}</p>
                </div>
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Cash</p>
                  <p className="text-xl font-black text-gray-900 dark:text-white">{shiftStats.cash}</p>
                </div>
                <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded-2xl">
                  <p className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-1">Card</p>
                  <p className="text-xl font-black text-gray-900 dark:text-white">{shiftStats.card}</p>
                </div>
              </div>

              <button
                onClick={() => setIsShiftSummaryOpen(false)}
                className="w-full bg-gray-900 dark:bg-zinc-800 text-white py-4 rounded-2xl font-bold hover:bg-gray-800 dark:hover:bg-zinc-700 transition-all"
              >
                Close Summary
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </DashboardLayout>
  );
}
